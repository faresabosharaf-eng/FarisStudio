# FARIS STUDIO (v0.3.0)

Working: open image, zoom/pan/rotate view, marquee + lasso selection (clips all painting), layers
(blend modes, opacity, lock, duplicate, move), brush presets, eraser, shapes, text, gradients,
fill with patterns/textures, eyedropper, filters (Blur, Sharpen, HDR + color looks), adjustments
(brightness/contrast, levels, exposure, hue/sat, color balance, B&W, photo filter, invert),
vignette, undo/redo, PNG export (Pictures/FarisStudio).
Dimmed (not yet): Crop, Healing, Clone Stamp, Blur/Dodge tools, Pen, Path Selection, Channels, Paths,
Styles, Curves and other adjustments.

Build: GitHub Actions (.github/workflows/build.yml) or Android Studio (JDK 17, Gradle 8.7).
