# FARIS STUDIO (Stages 1–2)

Android photo editor. This build has: dark UI, working menu bar, canvas with pinch-zoom / pan / two-finger view rotate,
mouse-wheel zoom, open image from gallery/files (JPG/PNG/WebP, EXIF-aware, auto down-sampled to 4096px), Properties panel,
hardware keyboard shortcuts (Help > Keyboard Shortcuts).

## Build
1. Install Android Studio (Koala or newer) with JDK 17 (bundled).
2. File > Open > select this folder. Let Gradle sync (it downloads Gradle 8.7 from gradle-wrapper.properties).
3. Run on a device/emulator (minSdk 26), or Build > Build APK(s).
   CLI after first sync: `./gradlew assembleDebug` -> app/build/outputs/apk/debug/app-debug.apk
4. AAB for Play: Build > Generate Signed Bundle / APK.

## Roadmap
Next: layers -> brush + history -> selection -> text/shapes -> filters -> masks/AI -> .farisproj save/export.
