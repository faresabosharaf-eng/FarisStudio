# FARIS STUDIO (v0.4.0)

UI follows the supplied design: top bar, menu bar, options bar, tool rail with color swatches,
Layers / Adjustments / Properties panels, bottom bar (tool group, Align, Distribute, Apply, Cancel).
All icons are drawn in code (no emoji).

Working: open image, pinch/pan/rotate view, Marquee + Lasso selections, Move (with Apply/Cancel and Align),
Brush (presets), Eraser, Gradient, Paint Bucket (patterns/textures), Type, Shape, Eyedropper, Hand, Zoom,
layers (blend, opacity, lock pixels/position/all, duplicate, delete), filters (Filter menu),
adjustments (8 of 15), vignette, undo/redo, PNG export (Pictures/FarisStudio).
Shown dimmed until implemented: Magic Wand, Crop, Blur, Healing, Pen, Path Selection, Feather, Select and Mask,
Channels, Paths, layer link/fx/mask/group, Distribute, rotate/flip, 7 adjustments.

Build: GitHub Actions or Android Studio (JDK 17, Gradle 8.7).
