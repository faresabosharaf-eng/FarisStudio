package com.faris.studio.core

import android.graphics.Bitmap

class TileDef(val id: String, val label: String)

/** Procedural 64x64 alpha tiles used for Patterns and Textures (tinted by the foreground color). */
object Tiles {
    val patterns = listOf(
        TileDef("p_stripes", "Stripes"), TileDef("p_dots", "Dots"), TileDef("p_checker", "Checker"),
        TileDef("p_grid", "Grid"), TileDef("p_diag", "Diagonal")
    )
    val textures = listOf(
        TileDef("t_noise", "Noise"), TileDef("t_paper", "Paper"),
        TileDef("t_canvas", "Canvas"), TileDef("t_fine", "Fine Grain")
    )
    private val cache = HashMap<String, Bitmap>()

    fun label(id: String?): String =
        (patterns + textures).firstOrNull { it.id == id }?.label ?: "Solid"

    fun get(id: String): Bitmap = cache.getOrPut(id) { build(id) }

    private fun build(id: String): Bitmap {
        val n = 64
        val px = IntArray(n * n)
        val rnd = java.util.Random(7)
        for (y in 0 until n) {
            for (x in 0 until n) {
                val a: Int = when (id) {
                    "p_stripes" -> if ((y / 8) % 2 == 0) 255 else 0
                    "p_dots" -> {
                        val dx = (x % 32) - 16
                        val dy = (y % 32) - 16
                        if (dx * dx + dy * dy <= 49) 255 else 0
                    }
                    "p_checker" -> if (((x / 16) + (y / 16)) % 2 == 0) 255 else 0
                    "p_grid" -> if (x % 16 < 2 || y % 16 < 2) 255 else 0
                    "p_diag" -> if (((x + y) / 8) % 2 == 0) 255 else 0
                    "t_noise" -> rnd.nextInt(150)
                    "t_paper" -> 10 + rnd.nextInt(60)
                    "t_canvas" -> if (((x / 2) + (y / 2)) % 2 == 0) 90 else 30
                    else -> if (rnd.nextInt(100) < 30) 140 else 0
                }
                px[y * n + x] = (a shl 24) or 0xFFFFFF
            }
        }
        return Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
    }
}

class BrushPreset(val name: String, val sizeFrac: Float, val soft: Float, val alpha: Float)

object Brushes {
    val list = listOf(
        BrushPreset("Hard Round", 0.15f, 0f, 1f),
        BrushPreset("Soft Round", 0.25f, 0.8f, 1f),
        BrushPreset("Pencil", 0.04f, 0f, 1f),
        BrushPreset("Marker", 0.12f, 0f, 0.6f),
        BrushPreset("Airbrush", 0.30f, 1f, 0.35f),
        BrushPreset("Ink", 0.06f, 0f, 1f)
    )
}

/** colors == null means Foreground to Background. */
class GradientPreset(val name: String, val colors: List<Long>?)

object Gradients {
    val list = listOf(
        GradientPreset("FG to BG", null),
        GradientPreset("Sunset", listOf(0xFFFF9500, 0xFFFF2D55, 0xFF5856D6)),
        GradientPreset("Ocean", listOf(0xFF00C7BE, 0xFF1E7BFF, 0xFF1B2A6B)),
        GradientPreset("Rainbow", listOf(0xFFFF3B30, 0xFFFF9500, 0xFFFFCC00, 0xFF34C759, 0xFF1E7BFF, 0xFFAF52DE)),
        GradientPreset("Fire", listOf(0xFFFFFF66, 0xFFFF9500, 0xFFFF3B30, 0xFF3A0000)),
        GradientPreset("Mono", listOf(0xFF000000, 0xFFFFFFFF))
    )
}
