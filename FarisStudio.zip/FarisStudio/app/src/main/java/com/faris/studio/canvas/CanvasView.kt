package com.faris.studio.canvas

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import com.faris.studio.EditorViewModel
import com.faris.studio.Tool
import com.faris.studio.ui.CanvasBg
import kotlin.math.pow

@Composable
fun CanvasView(vm: EditorViewModel, modifier: Modifier = Modifier) {
    val bmp = vm.bitmap
    val image = remember(bmp) { bmp?.asImageBitmap() }

    Box(
        modifier
            .fillMaxSize()
            .clipToBounds()
            .onSizeChanged { vm.canvasSize = it }
            // pinch / drag / two-finger rotate
            .pointerInput(Unit) {
                detectTransformGestures(panZoomLock = false) { centroid, pan, zoom, rot ->
                    if (vm.bitmap != null) vm.transform(centroid, pan, zoom, rot)
                }
            }
            // Zoom tool: tap = zoom in, double tap = zoom out
            .pointerInput(vm.tool) {
                if (vm.tool == Tool.Zoom) {
                    detectTapGestures(
                        onTap = { p -> if (vm.bitmap != null) vm.transform(p, Offset.Zero, 1.5f, 0f) },
                        onDoubleTap = { p -> if (vm.bitmap != null) vm.transform(p, Offset.Zero, 1f / 1.5f, 0f) }
                    )
                }
            }
            // Mouse wheel zoom (external mouse)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent()
                        if (ev.type == PointerEventType.Scroll && vm.bitmap != null) {
                            val ch = ev.changes.first()
                            val dy = ch.scrollDelta.y
                            vm.transform(ch.position, Offset.Zero, 1.15f.pow(-dy), 0f)
                            ch.consume()
                        }
                    }
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(CanvasBg)
            val img = image ?: return@Canvas
            val s = vm.scale
            val cx = size.width / 2f + vm.offset.x
            val cy = size.height / 2f + vm.offset.y
            val quality = when {
                s >= 4f -> FilterQuality.None
                s >= 1f -> FilterQuality.Low
                else -> FilterQuality.High
            }
            withTransform({
                translate(left = cx, top = cy)
                rotate(vm.rotation, Offset.Zero)
                scale(s, s, Offset.Zero)
                translate(left = -img.width / 2f, top = -img.height / 2f)
            }) {
                drawRect(Color.White, size = androidx.compose.ui.geometry.Size(img.width.toFloat(), img.height.toFloat()))
                drawImage(img, filterQuality = quality)
            }
        }
    }
}
