package com.faris.studio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.faris.studio.EditorViewModel
import com.faris.studio.SelMode
import com.faris.studio.Tool
import com.faris.studio.canvas.CanvasView
import com.faris.studio.core.Brushes
import com.faris.studio.core.Filters
import com.faris.studio.core.Gradients
import com.faris.studio.core.ShapeKind
import com.faris.studio.core.Tiles
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private class MenuEntry(
    val label: String,
    val shortcut: String = "",
    val checked: Boolean? = null,
    val enabled: Boolean = true,
    val onClick: () -> Unit
)

@Composable
fun EditorScreen(vm: EditorViewModel) {
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    var showSide by rememberSaveable { mutableStateOf(true) }
    var showToolbar by rememberSaveable { mutableStateOf(true) }
    var showAbout by remember { mutableStateOf(false) }
    var showKeys by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var showPanels by remember { mutableStateOf(false) }
    var showVignette by remember { mutableStateOf(false) }
    var moreOpen by remember { mutableStateOf(false) }
    var adjDialog by remember { mutableStateOf<Adj?>(null) }
    var colorTarget by remember { mutableStateOf<Int?>(null) } // 0 = foreground, 1 = background

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.openImage(uri)
    }
    val openImage = { launcher.launch(arrayOf("image/*")) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    LaunchedEffect(vm.message) {
        if (vm.message != null) {
            delay(3500)
            vm.dismissMessage()
        }
    }
    val hasImage = vm.bitmap != null

    val onAdj: (Adj) -> Unit = { a ->
        if (!a.implemented) {
            vm.toast("«${a.label}» غير مفعّلة بعد، قريباً")
        } else if (!hasImage) {
            vm.toast("افتح صورة أولاً")
        } else {
            when (a) {
                Adj.BlackWhite -> vm.setEditNow(vm.edit.copy(saturation = if (vm.edit.saturation <= -100) 0 else -100))
                Adj.Invert -> vm.setEditNow(vm.edit.copy(invert = !vm.edit.invert))
                else -> { adjDialog = a }
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(CanvasBg)
            .statusBarsPadding()
            .onKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
                val ctrl = e.isCtrlPressed
                when {
                    ctrl && e.key == Key.O -> { openImage(); true }
                    ctrl && e.key == Key.S -> { vm.exportPng(); true }
                    ctrl && e.key == Key.Z && e.isShiftPressed -> { vm.redo(); true }
                    ctrl && e.key == Key.Z -> { vm.undo(); true }
                    ctrl && e.key == Key.Y -> { vm.redo(); true }
                    ctrl && e.key == Key.A -> { vm.selectAll(); true }
                    ctrl && e.key == Key.D -> { vm.deselect(); true }
                    ctrl && (e.key == Key.Equals || e.key == Key.Plus || e.key == Key.NumPadAdd) -> { vm.zoomStep(1.25f); true }
                    ctrl && (e.key == Key.Minus || e.key == Key.NumPadSubtract) -> { vm.zoomStep(0.8f); true }
                    ctrl && e.key == Key.Zero -> { vm.fit(); true }
                    !ctrl && e.key == Key.M -> { vm.selectTool(Tool.Marquee); true }
                    !ctrl && e.key == Key.V -> { vm.selectTool(Tool.Move); true }
                    !ctrl && e.key == Key.L -> { vm.selectTool(Tool.Lasso); true }
                    !ctrl && e.key == Key.I -> { vm.selectTool(Tool.Picker); true }
                    !ctrl && e.key == Key.B -> { vm.selectTool(Tool.Brush); true }
                    !ctrl && e.key == Key.E -> { vm.selectTool(Tool.Eraser); true }
                    !ctrl && e.key == Key.G -> { vm.selectTool(Tool.Gradient); true }
                    !ctrl && e.key == Key.T -> { vm.selectTool(Tool.Text); true }
                    !ctrl && e.key == Key.U -> { vm.selectTool(Tool.Shape); true }
                    !ctrl && e.key == Key.H -> { vm.selectTool(Tool.Hand); true }
                    !ctrl && e.key == Key.Z -> { vm.selectTool(Tool.Zoom); true }
                    e.key == Key.Delete || e.key == Key.Backspace -> { vm.clearSelectionContent(); true }
                    e.key == Key.Enter -> { vm.applyPending(); true }
                    e.key == Key.Escape -> { vm.cancelPending(); true }
                    e.key == Key.F9 -> { showSide = !showSide; true }
                    e.key == Key.F11 -> { val v = !(showSide || showToolbar); showSide = v; showToolbar = v; true }
                    else -> false
                }
            }
            .focusRequester(focus)
            .focusable()
    ) {
        // ---------- Top bar ----------
        Row(
            Modifier.fillMaxWidth().background(BarBg).padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("F", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, fontStyle = FontStyle.Italic, color = Accent)
            Spacer(Modifier.width(10.dp))
            Text(buildAnnotatedString {
                withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.Bold)) { append("FARIS ") }
                withStyle(SpanStyle(color = Accent, fontWeight = FontWeight.Bold)) { append("STUDIO") }
            }, fontSize = 22.sp)
            Spacer(Modifier.weight(1f))
            TopIcon(Ic.Save, hasImage, Color.White) { vm.exportPng() }
            TopIcon(Ic.Undo, vm.canUndo, Color.White) { vm.undo() }
            TopIcon(Ic.Redo, vm.canRedo, Accent) { vm.redo() }
            Box {
                TopIcon(Ic.More, true, Color.White) { moreOpen = true }
                DropdownMenu(expanded = moreOpen, onDismissRequest = { moreOpen = false }) {
                    DropdownMenuItem(text = { Text("Panels") }, onClick = { moreOpen = false; showPanels = true })
                    DropdownMenuItem(text = { Text("Open Image…") }, onClick = { moreOpen = false; openImage() })
                }
            }
        }

        // ---------- Menu bar ----------
        Row(
            Modifier.fillMaxWidth().background(BarBg).horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MenuTitle("File", listOf(
                MenuEntry("Open Image…", "Ctrl+O") { openImage() },
                MenuEntry("Save / Export PNG", "Ctrl+S", enabled = hasImage) { vm.exportPng() }
            ))
            MenuTitle("Edit", listOf(
                MenuEntry("Undo", "Ctrl+Z", enabled = vm.canUndo) { vm.undo() },
                MenuEntry("Redo", "Ctrl+Y", enabled = vm.canRedo) { vm.redo() },
                MenuEntry("Fill (selection / layer)", enabled = hasImage) { vm.fillLayer() },
                MenuEntry("Clear selection", "Del", enabled = hasImage) { vm.clearSelectionContent() },
                MenuEntry("Reset adjustments", enabled = hasImage) { vm.resetEdits() }
            ))
            MenuTitle("Image", listOf(
                MenuEntry("Image Info", enabled = hasImage) { showInfo = true },
                MenuEntry("Adjustments…") { showPanels = true }
            ))
            MenuTitle("Layer", listOf(
                MenuEntry("New Layer", enabled = hasImage) { vm.addLayer() },
                MenuEntry("Duplicate Layer", enabled = hasImage) { vm.duplicateLayer() },
                MenuEntry("Delete Layer", enabled = hasImage) { vm.deleteActiveLayer() }
            ))
            MenuTitle("Select", listOf(
                MenuEntry("Select All", "Ctrl+A", enabled = hasImage) { vm.selectAll() },
                MenuEntry("Deselect", "Ctrl+D", enabled = hasImage) { vm.deselect() },
                MenuEntry("Inverse", enabled = hasImage) { vm.invertSelection() }
            ))
            MenuTitle("Filter",
                Filters.strip.map { p ->
                    MenuEntry(p.label, checked = vm.edit.filterId == p.id, enabled = hasImage) { vm.setFilter(p.id) }
                } + MenuEntry("Vignette…", enabled = hasImage) { showVignette = true }
            )
            MenuTitle("View", listOf(
                MenuEntry("Zoom In", "Ctrl +", enabled = hasImage) { vm.zoomStep(1.25f) },
                MenuEntry("Zoom Out", "Ctrl -", enabled = hasImage) { vm.zoomStep(0.8f) },
                MenuEntry("Fit Screen", "Ctrl 0", enabled = hasImage) { vm.fit() },
                MenuEntry("Actual Pixels (100%)", enabled = hasImage) { vm.actualSize() },
                MenuEntry("Rotate View 90\u00B0", enabled = hasImage) { vm.rotateView(90f) }
            ))
            MenuTitle("Window", listOf(
                MenuEntry("Toolbar", checked = showToolbar) { showToolbar = !showToolbar },
                MenuEntry("Side panels (tablet)", "F9", checked = showSide) { showSide = !showSide },
                MenuEntry("Panels") { showPanels = true }
            ))
            MenuTitle("Help", listOf(
                MenuEntry("Keyboard Shortcuts") { showKeys = true },
                MenuEntry("About FARIS STUDIO") { showAbout = true }
            ))
        }

        // ---------- Options bar ----------
        OptionsBar(vm)

        // ---------- Workspace ----------
        Row(Modifier.weight(1f).fillMaxWidth()) {
            if (showToolbar) {
                Column(Modifier.fillMaxHeight().width(60.dp).background(PanelBg)) {
                    Column(
                        Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Tool.rail.forEach { t ->
                            val sel = vm.tool == t || (t == Tool.Gradient && vm.tool == Tool.Fill)
                            ToolButton(t, sel) { vm.selectTool(t) }
                        }
                    }
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(48.dp)) {
                            Box(
                                Modifier.align(Alignment.BottomEnd).size(28.dp)
                                    .background(Color(vm.bgColor), RoundedCornerShape(3.dp))
                                    .border(1.dp, Color.White, RoundedCornerShape(3.dp))
                                    .clickable { colorTarget = 1 }
                            )
                            Box(
                                Modifier.align(Alignment.TopStart).padding(top = 4.dp).size(28.dp)
                                    .background(Color(vm.brushColor), RoundedCornerShape(3.dp))
                                    .border(1.dp, Color.White, RoundedCornerShape(3.dp))
                                    .clickable { colorTarget = 0 }
                            )
                            Box(Modifier.align(Alignment.TopEnd).size(18.dp).clickable { vm.swapColors() }, contentAlignment = Alignment.Center) {
                                FIcon(Ic.Swap, size = 14.dp, tint = TextDim)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Box(Modifier.alpha(0.5f).clickable { vm.toast("Quick Mask قريباً") }.padding(4.dp)) {
                            FIcon(Ic.QuickMask, size = 24.dp)
                        }
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxHeight()) {
                CanvasView(vm)
                if (!hasImage && !vm.loading) {
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("FARIS STUDIO", color = Accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { openImage() }) { Text("Open Image") }
                    }
                }
                if (vm.loading || vm.processing) CircularProgressIndicator(Modifier.align(Alignment.Center))
                vm.message?.let { m ->
                    Text(
                        m, fontSize = 13.sp, color = Color.White,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(10.dp)
                            .background(Color(0xDD000000), RoundedCornerShape(16.dp))
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
            if (wide && showSide) {
                SidePanel(
                    vm, onAdj,
                    Modifier.fillMaxHeight().width(320.dp).background(CanvasBg)
                        .verticalScroll(rememberScrollState()).padding(8.dp)
                )
            }
        }

        // ---------- Bottom bar (tool group, align, distribute, apply, cancel) ----------
        Row(
            Modifier.fillMaxWidth().background(BarBg).navigationBarsPadding()
                .horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ToolGroupButton(vm)
            Box(Modifier.width(1.dp).height(30.dp).background(Line))
            listOf(Ic.AlignT to 3, Ic.AlignMV to 4, Ic.AlignB to 5).forEach { (ic, k) ->
                BarIcon(ic, hasImage) { vm.alignActive(k) }
            }
            Box(Modifier.width(1.dp).height(30.dp).background(Line))
            Text("Align:", fontSize = 14.sp)
            listOf(Ic.AlignL to 0, Ic.AlignCH to 1, Ic.AlignR to 2).forEach { (ic, k) ->
                BarIcon(ic, hasImage) { vm.alignActive(k) }
            }
            Text("Distribute:", fontSize = 14.sp)
            listOf(Ic.DistA, Ic.DistB, Ic.DistC).forEach { ic ->
                Box(Modifier.alpha(0.45f).clickable { vm.toast("Distribute قريباً") }.padding(6.dp)) { FIcon(ic, size = 22.dp) }
            }
            val pending = vm.pendingMove != androidx.compose.ui.geometry.Offset.Zero
            Button(
                onClick = { vm.applyPending() }, enabled = pending,
                contentPadding = PaddingValues(horizontal = 22.dp)
            ) { Text("Apply", fontSize = 15.sp, fontWeight = FontWeight.Bold) }
            OutlinedButton(
                onClick = { vm.cancelPending() }, enabled = pending,
                contentPadding = PaddingValues(horizontal = 18.dp)
            ) { Text("Cancel", fontSize = 15.sp) }
        }
    }

    // ---------- Dialogs ----------
    if (vm.pendingTextPos != null) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { vm.pendingTextPos = null },
            confirmButton = { TextButton(onClick = { vm.confirmText(text) }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { vm.pendingTextPos = null }) { Text("Cancel") } },
            title = { Text("Type") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth()) }
        )
    }
    adjDialog?.let { a ->
        AlertDialog(
            onDismissRequest = { vm.commitPreview(); adjDialog = null },
            confirmButton = { TextButton(onClick = { vm.commitPreview(); adjDialog = null }) { Text("Done") } },
            dismissButton = { TextButton(onClick = { vm.resetEdits(); adjDialog = null }) { Text("Reset") } },
            title = { Text(a.label) },
            text = { AdjustDialogBody(vm, a) }
        )
    }
    if (showVignette) {
        AlertDialog(
            onDismissRequest = { vm.commitPreview(); showVignette = false },
            confirmButton = { TextButton(onClick = { vm.commitPreview(); showVignette = false }) { Text("Done") } },
            title = { Text("Vignette") },
            text = {
                LabeledSlider("Amount", vm.edit.vignette.toFloat(), 0f..100f, "${vm.edit.vignette}",
                    { vm.previewEdit(vm.edit.copy(vignette = it.roundToInt())) }, { vm.commitPreview() })
            }
        )
    }
    colorTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { colorTarget = null },
            confirmButton = { TextButton(onClick = { colorTarget = null }) { Text("OK") } },
            title = { Text(if (target == 0) "Foreground color" else "Background color") },
            text = {
                ColorPalette(if (target == 0) vm.brushColor else vm.bgColor) { c ->
                    if (target == 0) vm.brushColor = c else vm.bgColor = c
                }
            }
        )
    }
    if (showInfo) {
        val b = vm.bitmap
        AlertDialog(
            onDismissRequest = { showInfo = false },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text("OK") } },
            title = { Text("Image Info") },
            text = { Text("${vm.fileName}\n${b?.width ?: 0} \u00D7 ${b?.height ?: 0} px\nLayers: ${vm.layers.size + 1}") }
        )
    }
    if (showPanels) {
        Dialog(onDismissRequest = { showPanels = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(Modifier.fillMaxWidth(0.96f).fillMaxHeight(0.9f), shape = RoundedCornerShape(16.dp), color = CanvasBg) {
                Column {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Panels", fontSize = 16.sp, color = Accent, modifier = Modifier.weight(1f))
                        TextButton(onClick = { showPanels = false }) { Text("Close") }
                    }
                    SidePanel(vm, onAdj, Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp))
                }
            }
        }
    }
    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("OK") } },
            title = { Text("FARIS STUDIO") },
            text = { Text("Version 0.4.0") }
        )
    }
    if (showKeys) {
        AlertDialog(
            onDismissRequest = { showKeys = false },
            confirmButton = { TextButton(onClick = { showKeys = false }) { Text("OK") } },
            title = { Text("Keyboard Shortcuts") },
            text = {
                Text(
                    "Ctrl+O فتح  Ctrl+S حفظ  Ctrl+Z تراجع  Ctrl+Y إعادة\nCtrl+A تحديد الكل  Ctrl+D إلغاء التحديد\n" +
                        "M تحديد  V نقل  L لاسو  I قطارة  B فرشاة  E ممحاة\nG تدرج  T نص  U شكل  H يد  Z زوم\n" +
                        "Del مسح المحدد  Enter تطبيق  Esc إلغاء  Ctrl +/-/0 زوم  F9 اللوحات"
                )
            }
        )
    }
}

private fun groupItems(vm: EditorViewModel): List<Pair<String, () -> Unit>> = when (vm.tool) {
    Tool.Marquee -> listOf<Pair<String, () -> Unit>>(
        "Rectangular Marquee" to { vm.selMode = SelMode.Rectangle },
        "Elliptical Marquee" to { vm.selMode = SelMode.Ellipse }
    )
    Tool.Gradient, Tool.Fill -> listOf<Pair<String, () -> Unit>>(
        "Gradient" to { vm.selectTool(Tool.Gradient) },
        "Paint Bucket" to { vm.selectTool(Tool.Fill) }
    )
    Tool.Shape -> listOf<Pair<String, () -> Unit>>(
        "Rectangle" to { vm.shapeKind = ShapeKind.Rect },
        "Ellipse" to { vm.shapeKind = ShapeKind.Ellipse },
        "Line" to { vm.shapeKind = ShapeKind.Line }
    )
    else -> emptyList()
}

@Composable
private fun ToolGroupButton(vm: EditorViewModel) {
    var open by remember { mutableStateOf(false) }
    val items = groupItems(vm)
    Box {
        Row(
            Modifier.clickable(enabled = items.isNotEmpty()) { open = true }.padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FIcon(vm.tool.icon, size = 28.dp)
            if (items.isNotEmpty()) {
                Spacer(Modifier.width(6.dp))
                FIcon(Ic.Chevron, size = 16.dp)
            }
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            items.forEach { (name, act) ->
                DropdownMenuItem(text = { Text(name) }, onClick = { open = false; act() })
            }
        }
    }
}

@Composable
private fun OptionsBar(vm: EditorViewModel) {
    val t = vm.tool
    Row(
        Modifier.fillMaxWidth().background(PanelBg).horizontalScroll(rememberScrollState())
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ToolGroupButton(vm)
        when (t) {
            Tool.Marquee, Tool.Lasso -> {
                Text("Mode:", fontSize = 15.sp, color = TextDim)
                DropPick(
                    text = if (t == Tool.Lasso) "Freehand" else vm.selMode.name,
                    items = if (t == Tool.Lasso) listOf("Freehand") else listOf("Rectangle", "Ellipse"),
                    minWidth = 120.dp
                ) { i -> if (t == Tool.Marquee) vm.selMode = if (i == 0) SelMode.Rectangle else SelMode.Ellipse }
                Text("Feather:", fontSize = 15.sp, color = TextDim)
                DropPick(text = "0 px", items = listOf("0 px"), enabled = false, minWidth = 80.dp,
                    onDisabled = { vm.toast("Feather قريباً") }) {}
                Row(
                    Modifier.alpha(0.55f).clickable { vm.toast("Anti-alias قريباً") },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(22.dp).background(Accent, RoundedCornerShape(4.dp)), contentAlignment = Alignment.Center) {
                        FIcon(Ic.Check, size = 16.dp)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("Anti-alias", fontSize = 15.sp)
                }
                OutlinedButton(
                    onClick = { vm.toast("Select and Mask قريباً") },
                    modifier = Modifier.alpha(0.55f)
                ) { Text("Select and Mask…", fontSize = 14.sp) }
            }
            Tool.Brush -> {
                DropPick(
                    text = Brushes.list.firstOrNull { it.sizeFrac == vm.brushFrac && it.soft == vm.brushSoft }?.name ?: "Custom",
                    items = Brushes.list.map { it.name }, minWidth = 120.dp
                ) { i -> vm.selectBrushPreset(Brushes.list[i]) }
                MiniSlider("Size", vm.brushFrac, 0f..1f, "${vm.curSize().roundToInt()} px") { vm.brushFrac = it }
                MiniSlider("Opacity", vm.brushAlpha, 0.05f..1f, "${(vm.brushAlpha * 100).roundToInt()}%") { vm.brushAlpha = it }
                MiniSlider("Softness", vm.brushSoft, 0f..1f, "${(vm.brushSoft * 100).roundToInt()}") { vm.brushSoft = it }
            }
            Tool.Eraser -> {
                MiniSlider("Size", vm.brushFrac, 0f..1f, "${vm.curSize().roundToInt()} px") { vm.brushFrac = it }
                MiniSlider("Softness", vm.brushSoft, 0f..1f, "${(vm.brushSoft * 100).roundToInt()}") { vm.brushSoft = it }
            }
            Tool.Shape -> {
                Row(
                    Modifier.clickable { vm.shapeFilled = !vm.shapeFilled },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(22.dp).background(if (vm.shapeFilled) Accent else Color.Transparent, RoundedCornerShape(4.dp))
                            .border(1.dp, Line, RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center
                    ) { if (vm.shapeFilled) FIcon(Ic.Check, size = 16.dp) }
                    Spacer(Modifier.width(8.dp))
                    Text("Fill", fontSize = 15.sp)
                }
                MiniSlider("Stroke", vm.brushFrac, 0f..1f, "${vm.curSize().roundToInt()} px") { vm.brushFrac = it }
            }
            Tool.Gradient -> {
                DropPick(
                    text = Gradients.list[vm.gradIndex.coerceIn(0, Gradients.list.size - 1)].name,
                    items = Gradients.list.map { it.name }, minWidth = 120.dp
                ) { i -> vm.gradIndex = i }
                DropPick(text = if (vm.gradRadial) "Radial" else "Linear", items = listOf("Linear", "Radial"), minWidth = 100.dp) { i ->
                    vm.gradRadial = i == 1
                }
                MiniSlider("Opacity", vm.brushAlpha, 0.05f..1f, "${(vm.brushAlpha * 100).roundToInt()}%") { vm.brushAlpha = it }
            }
            Tool.Fill -> {
                val ids = listOf<String?>(null) + Tiles.patterns.map { it.id } + Tiles.textures.map { it.id }
                DropPick(
                    text = Tiles.label(vm.activeTile),
                    items = ids.map { Tiles.label(it) }, minWidth = 120.dp
                ) { i -> vm.activeTile = ids[i] }
                MiniSlider("Opacity", vm.brushAlpha, 0.05f..1f, "${(vm.brushAlpha * 100).roundToInt()}%") { vm.brushAlpha = it }
            }
            Tool.Text -> {
                MiniSlider("Size", vm.brushFrac, 0f..1f, "${(vm.curSize() * 3).roundToInt()} px") { vm.brushFrac = it }
            }
            Tool.Zoom -> {
                DropPick(text = if (vm.zoomOut) "Zoom Out" else "Zoom In", items = listOf("Zoom In", "Zoom Out"), minWidth = 110.dp) { i ->
                    vm.zoomOut = i == 1
                }
            }
            else -> {}
        }
    }
}

@Composable
private fun MenuTitle(title: String, entries: List<MenuEntry>) {
    var open by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { open = true }, contentPadding = PaddingValues(horizontal = 12.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            entries.forEach { e ->
                DropdownMenuItem(
                    text = { Text(e.label, fontSize = 14.sp) },
                    enabled = e.enabled,
                    onClick = { open = false; e.onClick() },
                    leadingIcon = if (e.checked == true) {
                        { FIcon(Ic.Check, size = 16.dp) }
                    } else null,
                    trailingIcon = if (e.shortcut.isNotEmpty()) {
                        { Text(e.shortcut, color = TextDim, fontSize = 11.sp) }
                    } else null
                )
            }
        }
    }
}

@Composable
private fun TopIcon(ic: Ic, enabled: Boolean, tint: Color, onClick: () -> Unit) {
    Box(
        Modifier.size(46.dp).alpha(if (enabled) 1f else 0.35f).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { FIcon(ic, size = 28.dp, tint = tint) }
}

@Composable
private fun BarIcon(ic: Ic, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.alpha(if (enabled) 1f else 0.4f).clickable(enabled = enabled, onClick = onClick).padding(6.dp)
    ) { FIcon(ic, size = 22.dp) }
}

@Composable
private fun ToolButton(t: Tool, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.padding(vertical = 2.dp).size(46.dp)
            .alpha(if (t.implemented) 1f else 0.4f)
            .background(if (selected) Selected else Color.Transparent, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { FIcon(t.icon, size = 28.dp) }
}
