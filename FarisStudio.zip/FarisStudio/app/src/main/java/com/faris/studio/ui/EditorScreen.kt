package com.faris.studio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.faris.studio.EditorViewModel
import com.faris.studio.SelMode
import com.faris.studio.Tool
import com.faris.studio.canvas.CanvasView
import com.faris.studio.core.Filters
import com.faris.studio.core.ShapeKind
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private class MenuEntry(
    val label: String,
    val shortcut: String = "",
    val checked: Boolean? = null,
    val enabled: Boolean = true,
    val onClick: () -> Unit
)

@Composable
fun EditorScreen(vm: EditorViewModel) {
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    var tab by rememberSaveable { mutableStateOf(BTab.Filters) }
    var showSide by rememberSaveable { mutableStateOf(true) }
    var showToolbar by rememberSaveable { mutableStateOf(true) }
    var showAbout by remember { mutableStateOf(false) }
    var showKeys by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var showPanels by remember { mutableStateOf(false) }
    var moreOpen by remember { mutableStateOf(false) }
    var adjDialog by remember { mutableStateOf<Adj?>(null) }
    var colorTarget by remember { mutableStateOf<Int?>(null) } // 0 = foreground, 1 = background

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.openImage(uri)
    }
    val openImage = { launcher.launch(arrayOf("image/*")) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    LaunchedEffect(vm.message) {
        if (vm.message != null) {
            delay(3500)
            vm.dismissMessage()
        }
    }
    val hasImage = vm.bitmap != null

    val onAdj: (Adj) -> Unit = { a ->
        if (!a.implemented) {
            vm.toast("«${a.label}» غير مفعّلة بعد، قريباً")
        } else if (!hasImage) {
            vm.toast("افتح صورة أولاً")
        } else {
            when (a) {
                Adj.BlackWhite -> vm.setEditNow(vm.edit.copy(saturation = if (vm.edit.saturation <= -100) 0 else -100))
                Adj.Invert -> vm.setEditNow(vm.edit.copy(invert = !vm.edit.invert))
                else -> { adjDialog = a }
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(CanvasBg)
            .statusBarsPadding()
            .onKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
                val ctrl = e.isCtrlPressed
                when {
                    ctrl && e.key == Key.O -> { openImage(); true }
                    ctrl && e.key == Key.S -> { vm.exportPng(); true }
                    ctrl && e.key == Key.Z && e.isShiftPressed -> { vm.redo(); true }
                    ctrl && e.key == Key.Z -> { vm.undo(); true }
                    ctrl && e.key == Key.Y -> { vm.redo(); true }
                    ctrl && e.key == Key.A -> { vm.selectAll(); true }
                    ctrl && e.key == Key.D -> { vm.deselect(); true }
                    ctrl && (e.key == Key.Equals || e.key == Key.Plus || e.key == Key.NumPadAdd) -> { vm.zoomStep(1.25f); true }
                    ctrl && (e.key == Key.Minus || e.key == Key.NumPadSubtract) -> { vm.zoomStep(0.8f); true }
                    ctrl && e.key == Key.Zero -> { vm.fit(); true }
                    !ctrl && e.key == Key.M -> { vm.selectTool(Tool.Marquee); true }
                    !ctrl && e.key == Key.V -> { vm.selectTool(Tool.Move); true }
                    !ctrl && e.key == Key.L -> { vm.selectTool(Tool.Lasso); true }
                    !ctrl && e.key == Key.I -> { vm.selectTool(Tool.Picker); true }
                    !ctrl && e.key == Key.B -> { vm.selectTool(Tool.Brush); true }
                    !ctrl && e.key == Key.E -> { vm.selectTool(Tool.Eraser); true }
                    !ctrl && e.key == Key.G -> { vm.selectTool(Tool.Gradient); true }
                    !ctrl && e.key == Key.F -> { vm.selectTool(Tool.Fill); true }
                    !ctrl && e.key == Key.T -> { vm.selectTool(Tool.Text); true }
                    !ctrl && e.key == Key.U -> { vm.selectTool(Tool.Shape); true }
                    !ctrl && e.key == Key.H -> { vm.selectTool(Tool.Hand); true }
                    !ctrl && e.key == Key.Z -> { vm.selectTool(Tool.Zoom); true }
                    e.key == Key.Delete || e.key == Key.Backspace -> { vm.clearSelectionContent(); true }
                    e.key == Key.F9 -> { showSide = !showSide; true }
                    e.key == Key.F11 -> { val v = !(showSide || showToolbar); showSide = v; showToolbar = v; true }
                    else -> false
                }
            }
            .focusRequester(focus)
            .focusable()
    ) {
        // ---------- Top bar ----------
        Row(
            Modifier.fillMaxWidth().background(BarBg).padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(30.dp).background(Accent, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                Text("F", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
            }
            Spacer(Modifier.width(8.dp))
            Text(buildAnnotatedString {
                withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.Bold)) { append("FARIS ") }
                withStyle(SpanStyle(color = Accent, fontWeight = FontWeight.Bold)) { append("STUDIO") }
            }, fontSize = 18.sp)
            Spacer(Modifier.weight(1f))
            TopIcon("💾", hasImage) { vm.exportPng() }
            TopIcon("↶", vm.canUndo) { vm.undo() }
            TopIcon("↷", vm.canRedo) { vm.redo() }
            Box {
                TopIcon("⋮", true) { moreOpen = true }
                DropdownMenu(expanded = moreOpen, onDismissRequest = { moreOpen = false }) {
                    DropdownMenuItem(text = { Text("Panels (Layers / Adjustments)") },
                        onClick = { moreOpen = false; showPanels = true })
                    DropdownMenuItem(text = { Text("Open Image…") },
                        onClick = { moreOpen = false; openImage() })
                }
            }
        }

        // ---------- Menu bar ----------
        Row(
            Modifier.fillMaxWidth().background(BarBg).horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MenuTitle("File", listOf(
                MenuEntry("Open Image…", "Ctrl+O") { openImage() },
                MenuEntry("Save / Export PNG", "Ctrl+S", enabled = hasImage) { vm.exportPng() }
            ))
            MenuTitle("Edit", listOf(
                MenuEntry("Undo", "Ctrl+Z", enabled = vm.canUndo) { vm.undo() },
                MenuEntry("Redo", "Ctrl+Y", enabled = vm.canRedo) { vm.redo() },
                MenuEntry("Fill (selection / layer)", "F", enabled = hasImage) { vm.fillLayer() },
                MenuEntry("Clear selection", "Del", enabled = hasImage) { vm.clearSelectionContent() },
                MenuEntry("Reset adjustments", enabled = hasImage) { vm.resetEdits() }
            ))
            MenuTitle("Image", listOf(
                MenuEntry("Image Info", enabled = hasImage) { showInfo = true },
                MenuEntry("Adjustments panel…") { showPanels = true }
            ))
            MenuTitle("Layer", listOf(
                MenuEntry("New Layer", enabled = hasImage) { vm.addLayer() },
                MenuEntry("Duplicate Layer", enabled = hasImage) { vm.duplicateLayer() },
                MenuEntry("Delete Layer", enabled = hasImage) { vm.deleteActiveLayer() }
            ))
            MenuTitle("Select", listOf(
                MenuEntry("Select All", "Ctrl+A", enabled = hasImage) { vm.selectAll() },
                MenuEntry("Deselect", "Ctrl+D", enabled = hasImage) { vm.deselect() },
                MenuEntry("Inverse", enabled = hasImage) { vm.invertSelection() }
            ))
            MenuTitle("Filter", Filters.strip.take(8).map { p ->
                MenuEntry(p.label, checked = vm.edit.filterId == p.id, enabled = hasImage) { vm.setFilter(p.id) }
            })
            MenuTitle("View", listOf(
                MenuEntry("Zoom In", "Ctrl +", enabled = hasImage) { vm.zoomStep(1.25f) },
                MenuEntry("Zoom Out", "Ctrl -", enabled = hasImage) { vm.zoomStep(0.8f) },
                MenuEntry("Fit Screen", "Ctrl 0", enabled = hasImage) { vm.fit() },
                MenuEntry("Actual Pixels (100%)", enabled = hasImage) { vm.actualSize() },
                MenuEntry("Rotate View 90°", enabled = hasImage) { vm.rotateView(90f) }
            ))
            MenuTitle("Window", listOf(
                MenuEntry("Toolbar", checked = showToolbar) { showToolbar = !showToolbar },
                MenuEntry("Side panels (tablet)", "F9", checked = showSide) { showSide = !showSide },
                MenuEntry("Panels…") { showPanels = true }
            ))
            MenuTitle("Help", listOf(
                MenuEntry("Keyboard Shortcuts") { showKeys = true },
                MenuEntry("About FARIS STUDIO") { showAbout = true }
            ))
        }

        // ---------- Options bar ----------
        OptionsBar(vm)

        // ---------- Workspace ----------
        Row(Modifier.weight(1f).fillMaxWidth()) {
            if (showToolbar) {
                Column(Modifier.fillMaxHeight().width(52.dp).background(PanelBg)) {
                    Column(
                        Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Tool.values().forEach { t -> ToolButton(t, vm.tool == t) { vm.selectTool(t) } }
                    }
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(40.dp)) {
                            Box(
                                Modifier.align(Alignment.BottomEnd).size(24.dp)
                                    .background(Color(vm.bgColor)).border(1.dp, Color.White)
                                    .clickable { colorTarget = 1 }
                            )
                            Box(
                                Modifier.align(Alignment.TopStart).size(24.dp)
                                    .background(Color(vm.brushColor)).border(1.dp, Color.White)
                                    .clickable { colorTarget = 0 }
                            )
                        }
                        Text("⇄", fontSize = 16.sp, color = TextDim,
                            modifier = Modifier.clickable { vm.swapColors() }.padding(4.dp))
                    }
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    CanvasView(vm)
                    if (!hasImage && !vm.loading) {
                        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("FARIS STUDIO", color = Accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = { openImage() }) { Text("Open Image") }
                        }
                    }
                    if (vm.loading) CircularProgressIndicator(Modifier.align(Alignment.Center))
                    vm.message?.let { m ->
                        Text(
                            m, fontSize = 13.sp, color = Color.White,
                            modifier = Modifier.align(Alignment.BottomCenter).padding(10.dp)
                                .background(Color(0xDD000000), RoundedCornerShape(16.dp))
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
                // Bottom strip: tabs + content
                Column(Modifier.fillMaxWidth().background(PanelBg)) {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        BTab.values().forEach { t ->
                            val sel = t == tab
                            Text(
                                t.label, fontSize = 13.sp,
                                color = if (sel) Accent else if (t.implemented) TextDim else TextDim.copy(alpha = 0.4f),
                                fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.clickable {
                                    if (t.implemented) tab = t else vm.toast("${t.label} قريباً")
                                }.padding(vertical = 8.dp)
                            )
                        }
                    }
                    Box(Modifier.fillMaxWidth().heightIn(max = 150.dp).verticalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp)) {
                        BottomStrip(vm, tab)
                    }
                }
            }
            if (wide && showSide) {
                SidePanel(
                    vm, onAdj,
                    Modifier.fillMaxHeight().width(300.dp).background(CanvasBg)
                        .verticalScroll(rememberScrollState()).padding(8.dp)
                )
            }
        }

        // ---------- Bottom bar ----------
        var zoomMenu by remember { mutableStateOf(false) }
        Row(
            Modifier.fillMaxWidth().background(BarBg).navigationBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box {
                OutlinedButton(onClick = { zoomMenu = true }, enabled = hasImage, contentPadding = PaddingValues(horizontal = 10.dp)) {
                    Text("${(vm.scale * 100).roundToInt()}% ▾", fontSize = 12.sp)
                }
                DropdownMenu(expanded = zoomMenu, onDismissRequest = { zoomMenu = false }) {
                    listOf(25, 50, 100, 200, 400, 800).forEach { z ->
                        DropdownMenuItem(text = { Text("$z%") }, onClick = { zoomMenu = false; vm.setZoom(z) })
                    }
                }
            }
            OutlinedButton(onClick = { vm.fit() }, enabled = hasImage, contentPadding = PaddingValues(horizontal = 10.dp)) {
                Text(if (wide) "⛶ Fit Screen" else "⛶ Fit", fontSize = 12.sp)
            }
            BarIcon("−", hasImage) { vm.zoomStep(0.8f) }
            BarIcon("+", hasImage) { vm.zoomStep(1.25f) }
            BarIcon("⟳", hasImage) { vm.fit() }
            Spacer(Modifier.weight(1f))
            Button(onClick = { vm.exportPng() }, enabled = hasImage, contentPadding = PaddingValues(horizontal = 16.dp)) {
                Text("⬇ Save", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    // ---------- Dialogs ----------
    if (vm.pendingTextPos != null) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { vm.pendingTextPos = null },
            confirmButton = { TextButton(onClick = { vm.confirmText(text) }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { vm.pendingTextPos = null }) { Text("Cancel") } },
            title = { Text("Text") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth()) }
        )
    }
    adjDialog?.let { a ->
        AlertDialog(
            onDismissRequest = { vm.commitPreview(); adjDialog = null },
            confirmButton = { TextButton(onClick = { vm.commitPreview(); adjDialog = null }) { Text("Done") } },
            dismissButton = { TextButton(onClick = { vm.resetEdits(); adjDialog = null }) { Text("Reset") } },
            title = { Text(a.label) },
            text = { AdjustDialogBody(vm, a) }
        )
    }
    colorTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { colorTarget = null },
            confirmButton = { TextButton(onClick = { colorTarget = null }) { Text("OK") } },
            title = { Text(if (target == 0) "Foreground color" else "Background color") },
            text = {
                ColorPalette(if (target == 0) vm.brushColor else vm.bgColor) { c ->
                    if (target == 0) vm.brushColor = c else vm.bgColor = c
                }
            }
        )
    }
    if (showInfo) {
        val b = vm.bitmap
        AlertDialog(
            onDismissRequest = { showInfo = false },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text("OK") } },
            title = { Text("Image Info") },
            text = { Text("${vm.fileName}\n${b?.width ?: 0} × ${b?.height ?: 0} px\nLayers: ${vm.layers.size + 1}") }
        )
    }
    if (showPanels) {
        Dialog(onDismissRequest = { showPanels = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(Modifier.fillMaxWidth(0.96f).fillMaxHeight(0.9f), shape = RoundedCornerShape(16.dp), color = CanvasBg) {
                Column {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Panels", fontSize = 16.sp, color = Accent, modifier = Modifier.weight(1f))
                        Text("✕", fontSize = 20.sp, modifier = Modifier.clickable { showPanels = false }.padding(8.dp))
                    }
                    SidePanel(vm, onAdj, Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp))
                }
            }
        }
    }
    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("OK") } },
            title = { Text("FARIS STUDIO") },
            text = { Text("Version 0.3.0\nتحديد (Marquee/Lasso)، طبقات متقدمة، فلاتر (Blur/Sharpen/HDR)، تعديلات، فرش، تدرجات، أنماط وملمسات، وحفظ PNG.") }
        )
    }
    if (showKeys) {
        AlertDialog(
            onDismissRequest = { showKeys = false },
            confirmButton = { TextButton(onClick = { showKeys = false }) { Text("OK") } },
            title = { Text("Keyboard Shortcuts") },
            text = {
                Text(
                    "Ctrl+O فتح  Ctrl+S حفظ  Ctrl+Z تراجع  Ctrl+Y إعادة\nCtrl+A تحديد الكل  Ctrl+D إلغاء التحديد\n" +
                        "M تحديد  V نقل  L لاسو  I قطارة  B فرشاة  E ممحاة\nG تدرج  F تعبئة  T نص  U شكل  H يد  Z زوم\n" +
                        "Del مسح المحدد  Ctrl +/-/0 زوم  F9 اللوحات"
                )
            }
        )
    }
}

@Composable
private fun OptionsBar(vm: EditorViewModel) {
    val t = vm.tool
    Row(
        Modifier.fillMaxWidth().background(PanelBg).horizontalScroll(rememberScrollState())
            .padding(horizontal = 10.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(t.glyph, fontSize = 20.sp)
        Text(t.label, fontSize = 13.sp, color = Accent)
        when (t) {
            Tool.Marquee -> {
                SelMode.values().forEach { m ->
                    FilterChip(selected = vm.selMode == m, onClick = { vm.selMode = m }, label = { Text(m.name, fontSize = 12.sp) })
                }
                OptButton("Select All") { vm.selectAll() }
                OptButton("Deselect") { vm.deselect() }
                OptButton("Inverse") { vm.invertSelection() }
            }
            Tool.Lasso -> {
                OptButton("Deselect") { vm.deselect() }
                OptButton("Inverse") { vm.invertSelection() }
            }
            Tool.Brush -> {
                MiniSlider("Size", vm.brushFrac, 0f..1f, "${vm.curSize().roundToInt()}px") { vm.brushFrac = it }
                MiniSlider("Opacity", vm.brushAlpha, 0.05f..1f, "${(vm.brushAlpha * 100).roundToInt()}%") { vm.brushAlpha = it }
                MiniSlider("Soft", vm.brushSoft, 0f..1f, "${(vm.brushSoft * 100).roundToInt()}") { vm.brushSoft = it }
            }
            Tool.Eraser -> {
                MiniSlider("Size", vm.brushFrac, 0f..1f, "${vm.curSize().roundToInt()}px") { vm.brushFrac = it }
                MiniSlider("Soft", vm.brushSoft, 0f..1f, "${(vm.brushSoft * 100).roundToInt()}") { vm.brushSoft = it }
            }
            Tool.Shape -> {
                ShapeKind.values().forEach { k ->
                    FilterChip(selected = vm.shapeKind == k, onClick = { vm.shapeKind = k }, label = { Text(k.name, fontSize = 12.sp) })
                }
                FilterChip(selected = vm.shapeFilled, onClick = { vm.shapeFilled = !vm.shapeFilled }, label = { Text("Fill", fontSize = 12.sp) })
                MiniSlider("Stroke", vm.brushFrac, 0f..1f, "${vm.curSize().roundToInt()}px") { vm.brushFrac = it }
            }
            Tool.Gradient -> {
                FilterChip(selected = !vm.gradRadial, onClick = { vm.gradRadial = false }, label = { Text("Linear", fontSize = 12.sp) })
                FilterChip(selected = vm.gradRadial, onClick = { vm.gradRadial = true }, label = { Text("Radial", fontSize = 12.sp) })
                MiniSlider("Opacity", vm.brushAlpha, 0.05f..1f, "${(vm.brushAlpha * 100).roundToInt()}%") { vm.brushAlpha = it }
                Text("اسحب على الصورة، والتدرجات من تبويب Gradients", fontSize = 11.sp, color = TextDim)
            }
            Tool.Fill -> {
                Text("Fill: ${com.faris.studio.core.Tiles.label(vm.activeTile)}", fontSize = 12.sp)
                MiniSlider("Opacity", vm.brushAlpha, 0.05f..1f, "${(vm.brushAlpha * 100).roundToInt()}%") { vm.brushAlpha = it }
                Text("اضغط لتعبئة التحديد أو الطبقة", fontSize = 11.sp, color = TextDim)
            }
            Tool.Text -> {
                MiniSlider("Size", vm.brushFrac, 0f..1f, "${(vm.curSize() * 3).roundToInt()}px") { vm.brushFrac = it }
                Text("اضغط على الصورة لكتابة نص", fontSize = 11.sp, color = TextDim)
            }
            Tool.Zoom -> {
                FilterChip(selected = !vm.zoomOut, onClick = { vm.zoomOut = false }, label = { Text("Zoom In", fontSize = 12.sp) })
                FilterChip(selected = vm.zoomOut, onClick = { vm.zoomOut = true }, label = { Text("Zoom Out", fontSize = 12.sp) })
            }
            Tool.Move -> Text("اسحب لتحريك الطبقة المحددة (طبقات الرسم فقط)", fontSize = 11.sp, color = TextDim)
            Tool.Picker -> Text("اضغط على أي نقطة لالتقاط لونها", fontSize = 11.sp, color = TextDim)
            Tool.Hand -> Text("حرّك الصورة بإصبع، وكبّر بإصبعين", fontSize = 11.sp, color = TextDim)
            else -> {}
        }
    }
}

@Composable
private fun OptButton(text: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 10.dp), modifier = Modifier.height(34.dp)) {
        Text(text, fontSize = 12.sp)
    }
}

@Composable
private fun MenuTitle(title: String, entries: List<MenuEntry>) {
    var open by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { open = true }, contentPadding = PaddingValues(horizontal = 10.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            entries.forEach { e ->
                DropdownMenuItem(
                    text = { Text((if (e.checked == true) "✓ " else "") + e.label, fontSize = 14.sp) },
                    enabled = e.enabled,
                    onClick = { open = false; e.onClick() },
                    trailingIcon = if (e.shortcut.isNotEmpty()) {
                        { Text(e.shortcut, color = TextDim, fontSize = 11.sp) }
                    } else null
                )
            }
        }
    }
}

@Composable
private fun TopIcon(glyph: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).alpha(if (enabled) 1f else 0.35f).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(glyph, fontSize = 20.sp) }
}

@Composable
private fun BarIcon(glyph: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).alpha(if (enabled) 1f else 0.35f)
            .background(PanelBg, RoundedCornerShape(17.dp)).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(glyph, fontSize = 16.sp) }
}

@Composable
private fun ToolButton(t: Tool, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.padding(vertical = 2.dp).size(42.dp)
            .alpha(if (t.implemented) 1f else 0.35f)
            .background(if (selected) Selected else Color.Transparent, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(t.glyph, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}
