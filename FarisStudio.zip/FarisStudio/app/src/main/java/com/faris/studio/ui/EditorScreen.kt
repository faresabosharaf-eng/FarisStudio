package com.faris.studio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.faris.studio.EditorViewModel
import com.faris.studio.Tool
import com.faris.studio.canvas.CanvasView
import kotlin.math.roundToInt

private data class MenuEntry(
    val label: String,
    val shortcut: String = "",
    val checked: Boolean? = null,
    val enabled: Boolean = true,
    val onClick: () -> Unit
)

@Composable
fun EditorScreen(vm: EditorViewModel) {
    var showProps by rememberSaveable { mutableStateOf(true) }
    var showToolbar by rememberSaveable { mutableStateOf(true) }
    var showAbout by remember { mutableStateOf(false) }
    var showKeys by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.openImage(uri)
    }
    val openImage = { launcher.launch(arrayOf("image/*")) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    val hasImage = vm.bitmap != null

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .onKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
                when {
                    e.isCtrlPressed && e.key == Key.O -> { openImage(); true }
                    e.isCtrlPressed && (e.key == Key.Equals || e.key == Key.Plus || e.key == Key.NumPadAdd) -> { vm.zoomStep(1.25f); true }
                    e.isCtrlPressed && (e.key == Key.Minus || e.key == Key.NumPadSubtract) -> { vm.zoomStep(0.8f); true }
                    e.isCtrlPressed && e.key == Key.Zero -> { vm.fit(); true }
                    !e.isCtrlPressed && e.key == Key.H -> { vm.tool = Tool.Hand; true }
                    !e.isCtrlPressed && e.key == Key.Z -> { vm.tool = Tool.Zoom; true }
                    e.key == Key.F9 -> { showProps = !showProps; true }
                    e.key == Key.F11 -> { val v = !(showProps || showToolbar); showProps = v; showToolbar = v; true }
                    else -> false
                }
            }
            .focusRequester(focus)
            .focusable()
    ) {
        // ---------- Menu bar ----------
        Row(
            Modifier
                .fillMaxWidth()
                .background(BarBg)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("FARIS", color = Accent, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 10.dp))
            MenuTitle("File", listOf(
                MenuEntry("Open Image…", "Ctrl+O") { openImage() }
            ))
            MenuTitle("View", listOf(
                MenuEntry("Zoom In", "Ctrl +", enabled = hasImage) { vm.zoomStep(1.25f) },
                MenuEntry("Zoom Out", "Ctrl -", enabled = hasImage) { vm.zoomStep(0.8f) },
                MenuEntry("Fit Screen", "Ctrl 0", enabled = hasImage) { vm.fit() },
                MenuEntry("Actual Pixels (100%)", enabled = hasImage) { vm.actualSize() },
                MenuEntry("Rotate View 90°", enabled = hasImage) { vm.rotateView(90f) },
                MenuEntry("Reset View Rotation", enabled = hasImage) {
                    vm.rotateView(-vm.rotation); vm.fit()
                }
            ))
            MenuTitle("Window", listOf(
                MenuEntry("Properties", "F9", checked = showProps) { showProps = !showProps },
                MenuEntry("Toolbar", checked = showToolbar) { showToolbar = !showToolbar },
                MenuEntry("Toggle All Panels", "F11") {
                    val v = !(showProps || showToolbar); showProps = v; showToolbar = v
                }
            ))
            MenuTitle("Help", listOf(
                MenuEntry("Keyboard Shortcuts") { showKeys = true },
                MenuEntry("About FARIS STUDIO") { showAbout = true }
            ))
        }

        // ---------- Workspace ----------
        Row(Modifier.weight(1f).fillMaxWidth()) {
            if (showToolbar) {
                Column(
                    Modifier
                        .fillMaxHeight()
                        .width(60.dp)
                        .background(PanelBg)
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ToolButton("Hand\n(H)", vm.tool == Tool.Hand) { vm.tool = Tool.Hand }
                    ToolButton("Zoom\n(Z)", vm.tool == Tool.Zoom) { vm.tool = Tool.Zoom }
                }
            }

            Box(Modifier.weight(1f).fillMaxHeight()) {
                CanvasView(vm)
                if (!hasImage && !vm.loading) {
                    Column(
                        Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("FARIS STUDIO", color = Accent, fontSize = 22.sp)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { openImage() }) { Text("Open Image") }
                    }
                }
                if (vm.loading) CircularProgressIndicator(Modifier.align(Alignment.Center))
            }

            if (showProps) {
                Column(
                    Modifier
                        .fillMaxHeight()
                        .width(190.dp)
                        .background(PanelBg)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Properties", color = Accent, fontSize = 14.sp)
                    val b = vm.bitmap
                    if (b == null) {
                        Text("No image", color = TextDim, fontSize = 12.sp)
                    } else {
                        PropRow("Name", vm.fileName)
                        PropRow("Size", "${b.width} × ${b.height} px")
                        PropRow("Zoom", "${(vm.scale * 100).roundToInt()}%")
                        PropRow("View rotation", "${vm.rotation.roundToInt()}°")
                    }
                }
            }
        }

        // ---------- Status bar ----------
        Row(
            Modifier
                .fillMaxWidth()
                .background(BarBg)
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                vm.error ?: if (hasImage) vm.fileName else "Ready",
                color = if (vm.error != null) MaterialTheme.colorScheme.error else TextDim,
                fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f)
            )
            if (hasImage) Text("${(vm.scale * 100).roundToInt()}%", color = TextDim, fontSize = 12.sp)
        }
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("OK") } },
            title = { Text("FARIS STUDIO") },
            text = { Text("Version 0.1.0\nStages 1–2: interface, canvas (zoom / pan / rotate view) and image opening.") }
        )
    }
    if (showKeys) {
        AlertDialog(
            onDismissRequest = { showKeys = false },
            confirmButton = { TextButton(onClick = { showKeys = false }) { Text("OK") } },
            title = { Text("Keyboard Shortcuts") },
            text = {
                Text(
                    "Ctrl+O  Open image\nCtrl +  Zoom in\nCtrl -  Zoom out\nCtrl 0  Fit screen\n" +
                        "H  Hand tool\nZ  Zoom tool\nF9  Properties panel\nF11  Toggle panels\n" +
                        "Mouse wheel  Zoom"
                )
            }
        )
    }
}

@Composable
private fun MenuTitle(title: String, entries: List<MenuEntry>) {
    var open by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { open = true }, contentPadding = PaddingValues(horizontal = 10.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            entries.forEach { e ->
                DropdownMenuItem(
                    text = { Text((if (e.checked == true) "✓ " else "") + e.label, fontSize = 14.sp) },
                    enabled = e.enabled,
                    onClick = { open = false; e.onClick() },
                    trailingIcon = if (e.shortcut.isNotEmpty()) {
                        { Text(e.shortcut, color = TextDim, fontSize = 11.sp) }
                    } else null
                )
            }
        }
    }
}

@Composable
private fun ToolButton(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(48.dp)
            .background(if (selected) Accent.copy(alpha = 0.3f) else BarBg, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 10.sp, color = if (selected) Accent else TextDim, lineHeight = 12.sp)
    }
}

@Composable
private fun PropRow(k: String, v: String) {
    Column {
        Text(k, color = TextDim, fontSize = 11.sp)
        Text(v, fontSize = 13.sp, maxLines = 2)
    }
}
