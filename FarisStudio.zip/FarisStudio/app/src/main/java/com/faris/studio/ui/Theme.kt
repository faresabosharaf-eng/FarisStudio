package com.faris.studio.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PanelBg = Color(0xFF2B2B2B)
val BarBg = Color(0xFF323232)
val CanvasBg = Color(0xFF191919)
val Accent = Color(0xFF31A8FF)
val TextDim = Color(0xFFB0B0B0)

private val Scheme = darkColorScheme(
    primary = Accent,
    background = Color(0xFF1E1E1E),
    surface = PanelBg,
    onSurface = Color(0xFFE6E6E6),
    onBackground = Color(0xFFE6E6E6),
    surfaceVariant = BarBg
)

@Composable
fun FarisTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
