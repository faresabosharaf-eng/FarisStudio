package com.faris.studio.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class Ic {
    Marquee, Move, Lasso, Wand, Brush, Crop, Eyedropper, Eraser, Gradient, Drop, Healing, Pen, Type,
    PathSel, Shape, Hand, Zoom, QuickMask, Swap,
    Save, Undo, Redo, More, Chevron, Check, Eye, Search,
    KindImage, KindAdj, KindType, KindShape, KindSmart,
    LockTransp, LockPixels, LockPos, LockAll,
    Link, Fx, Mask, AdjLayer, Folder, Trash, Menu,
    Sun, Curves, Levels, Exposure, Vibrance, HueSat, Balance, BW, Mixer, Camera, GradMap, Lookup,
    Invert, Posterize, Threshold,
    PixelLayer, FlipH, FlipV, AlignL, AlignCH, AlignR, AlignT, AlignMV, AlignB, DistA, DistB, DistC, Angle
}

@Composable
fun FIcon(ic: Ic, modifier: Modifier = Modifier, size: Dp = 24.dp, tint: Color = Color.White) {
    Canvas(modifier.size(size)) { drawIc(ic, tint) }
}

private fun DrawScope.drawIc(ic: Ic, c: Color) {
    val u = size.minDimension / 24f
    val sw = 1.8f * u

    fun ln(x1: Float, y1: Float, x2: Float, y2: Float, w: Float = sw) =
        drawLine(c, Offset(x1 * u, y1 * u), Offset(x2 * u, y2 * u), strokeWidth = w, cap = StrokeCap.Round)

    fun rs(l: Float, t: Float, r: Float, b: Float) =
        drawRect(c, Offset(l * u, t * u), Size((r - l) * u, (b - t) * u), style = Stroke(sw))

    fun rf(l: Float, t: Float, r: Float, b: Float) =
        drawRect(c, Offset(l * u, t * u), Size((r - l) * u, (b - t) * u))

    fun cs(cx: Float, cy: Float, r: Float) =
        drawCircle(c, r * u, Offset(cx * u, cy * u), style = Stroke(sw))

    fun cf(cx: Float, cy: Float, r: Float) =
        drawCircle(c, r * u, Offset(cx * u, cy * u))

    fun poly(vararg p: Float, close: Boolean = true, fill: Boolean = false) {
        val path = Path()
        path.moveTo(p[0] * u, p[1] * u)
        var i = 2
        while (i < p.size) {
            path.lineTo(p[i] * u, p[i + 1] * u)
            i += 2
        }
        if (close) path.close()
        drawPath(path, c, style = if (fill) Fill else Stroke(sw, join = StrokeJoin.Round, cap = StrokeCap.Round))
    }

    fun mountains() {
        poly(5f, 17f, 9.5f, 11f, 12.5f, 14.5f, 15f, 12f, 19f, 17f, close = false)
    }

    when (ic) {
        Ic.Marquee -> drawRect(
            c, Offset(4f * u, 4f * u), Size(16f * u, 16f * u),
            style = Stroke(sw, pathEffect = PathEffect.dashPathEffect(floatArrayOf(3f * u, 2.6f * u)))
        )
        Ic.Move -> {
            ln(12f, 3f, 12f, 21f); ln(3f, 12f, 21f, 12f)
            poly(9f, 6f, 12f, 3f, 15f, 6f, close = false); poly(9f, 18f, 12f, 21f, 15f, 18f, close = false)
            poly(6f, 9f, 3f, 12f, 6f, 15f, close = false); poly(18f, 9f, 21f, 12f, 18f, 15f, close = false)
        }
        Ic.Lasso -> {
            drawOval(c, Offset(3f * u, 4f * u), Size(18f * u, 11f * u), style = Stroke(sw))
            ln(9f, 15f, 7f, 19f); cf(6.3f, 20.2f, 1.3f)
        }
        Ic.Wand -> {
            ln(4f, 20f, 15f, 9f, 2.8f * u)
            ln(17f, 3f, 17f, 8f); ln(14.5f, 5.5f, 19.5f, 5.5f)
            ln(20f, 11f, 20f, 14f); ln(18.5f, 12.5f, 21.5f, 12.5f)
        }
        Ic.Brush -> {
            ln(10f, 14f, 19f, 5f, 2.8f * u)
            cf(7f, 17f, 3.4f)
        }
        Ic.Crop -> {
            poly(7f, 3f, 7f, 17f, 21f, 17f, close = false)
            poly(3f, 7f, 17f, 7f, 17f, 21f, close = false)
        }
        Ic.Eyedropper -> {
            ln(14f, 10f, 5f, 19f, 2.4f * u); ln(12f, 8f, 16f, 12f)
            cf(18f, 6f, 2.8f); cf(4.5f, 19.5f, 1.2f)
        }
        Ic.Eraser -> {
            poly(3.5f, 14f, 11.5f, 5.5f, 19.5f, 11.5f, 13f, 19.5f, 8f, 19.5f)
            ln(7.5f, 10.5f, 14.5f, 16f); ln(4f, 22f, 20f, 22f)
        }
        Ic.Gradient -> {
            rs(4f, 4f, 20f, 20f)
            for (i in 0 until 4) {
                val x = 7f + i * 3.4f
                drawLine(c.copy(alpha = 0.3f + 0.2f * i), Offset(x * u, 5f * u), Offset(x * u, 19f * u), strokeWidth = 2.4f * u)
            }
        }
        Ic.Drop -> {
            cs(12f, 15f, 5.5f)
            poly(12f, 3f, 7.2f, 12f, 16.8f, 12f)
        }
        Ic.Healing -> {
            ln(13f, 11f, 5f, 19f, 2.4f * u); ln(11f, 9f, 15f, 13f)
            cf(17.5f, 6.5f, 2.6f)
            ln(18f, 16f, 18f, 21f); ln(15.5f, 18.5f, 20.5f, 18.5f)
        }
        Ic.Pen -> {
            poly(5f, 19f, 7f, 13f, 16f, 4f, 20f, 8f, 11f, 17f)
            ln(14f, 6f, 18f, 10f); ln(4f, 21.5f, 10f, 21.5f)
        }
        Ic.Type -> {
            ln(5f, 5f, 19f, 5f); ln(12f, 5f, 12f, 20f); ln(9f, 20f, 15f, 20f)
        }
        Ic.PathSel -> poly(6f, 3f, 6f, 18f, 10f, 14f, 13f, 21f, 15.5f, 20f, 12.5f, 13f, 18f, 13f)
        Ic.Shape -> rs(4f, 6f, 20f, 18f)
        Ic.Hand -> {
            ln(8f, 11f, 8f, 5.5f); ln(11f, 10.5f, 11f, 4f); ln(14f, 10.5f, 14f, 4.5f); ln(17f, 11f, 17f, 7f)
            poly(8f, 11f, 8f, 17f, 10.5f, 20.5f, 15.5f, 20.5f, 17f, 17f, 17f, 11f, close = false)
            ln(8f, 15f, 5f, 12.5f)
        }
        Ic.Zoom -> { cs(10f, 10f, 6f); ln(14.5f, 14.5f, 20f, 20f, 2.4f * u) }
        Ic.QuickMask -> { rs(4f, 4f, 20f, 20f); cs(12f, 12f, 4f) }
        Ic.Swap -> {
            poly(5f, 10f, 5f, 5f, 10f, 5f, close = false); ln(5f, 5f, 11f, 11f)
            poly(19f, 14f, 19f, 19f, 14f, 19f, close = false); ln(19f, 19f, 13f, 13f)
        }
        Ic.Save -> {
            rs(4f, 4f, 20f, 20f); rs(8f, 4f, 16f, 9f); rs(7f, 13f, 17f, 20f)
        }
        Ic.Undo -> {
            poly(9f, 6f, 5f, 10f, 9f, 14f, close = false); ln(5f, 10f, 14f, 10f)
            drawArc(c, -90f, 180f, false, Offset(9f * u, 10f * u), Size(10f * u, 10f * u),
                style = Stroke(sw, cap = StrokeCap.Round))
            ln(14f, 20f, 9f, 20f)
        }
        Ic.Redo -> {
            poly(15f, 6f, 19f, 10f, 15f, 14f, close = false); ln(19f, 10f, 10f, 10f)
            drawArc(c, -90f, -180f, false, Offset(5f * u, 10f * u), Size(10f * u, 10f * u),
                style = Stroke(sw, cap = StrokeCap.Round))
            ln(10f, 20f, 15f, 20f)
        }
        Ic.More -> { cf(12f, 5f, 1.8f); cf(12f, 12f, 1.8f); cf(12f, 19f, 1.8f) }
        Ic.Chevron -> poly(6f, 9f, 12f, 15f, 18f, 9f, close = false)
        Ic.Check -> poly(5f, 12f, 10f, 17f, 19f, 7f, close = false)
        Ic.Eye -> {
            drawOval(c, Offset(2.5f * u, 6.5f * u), Size(19f * u, 11f * u), style = Stroke(sw)); cf(12f, 12f, 3f)
        }
        Ic.Search -> { cs(10f, 10f, 5.5f); ln(14.5f, 14.5f, 20f, 20f) }
        Ic.KindImage, Ic.PixelLayer -> { rs(4f, 5f, 20f, 19f); mountains() }
        Ic.KindAdj, Ic.AdjLayer, Ic.BW -> {
            cs(12f, 12f, 8f)
            drawArc(c, -90f, 180f, true, Offset(4f * u, 4f * u), Size(16f * u, 16f * u))
        }
        Ic.KindType -> { ln(5f, 5f, 19f, 5f); ln(12f, 5f, 12f, 20f); ln(9f, 20f, 15f, 20f) }
        Ic.KindShape -> { rs(6f, 6f, 18f, 18f); cf(5f, 5f, 1.6f); cf(19f, 5f, 1.6f); cf(5f, 19f, 1.6f); cf(19f, 19f, 1.6f) }
        Ic.KindSmart -> { rs(4f, 4f, 17f, 17f); rs(8f, 8f, 20f, 20f) }
        Ic.LockTransp -> { rs(4f, 4f, 20f, 20f); rf(4f, 4f, 12f, 12f); rf(12f, 12f, 20f, 20f) }
        Ic.LockPixels -> { ln(10f, 14f, 19f, 5f, 2.8f * u); cf(7f, 17f, 3.4f) }
        Ic.LockPos -> {
            ln(12f, 3f, 12f, 21f); ln(3f, 12f, 21f, 12f)
            poly(9f, 6f, 12f, 3f, 15f, 6f, close = false); poly(9f, 18f, 12f, 21f, 15f, 18f, close = false)
            poly(6f, 9f, 3f, 12f, 6f, 15f, close = false); poly(18f, 9f, 21f, 12f, 18f, 15f, close = false)
        }
        Ic.LockAll -> {
            rs(6f, 11f, 18f, 20f)
            drawArc(c, 180f, 180f, false, Offset(8f * u, 4f * u), Size(8f * u, 10f * u), style = Stroke(sw))
        }
        Ic.Link -> {
            drawOval(c, Offset(2.5f * u, 9f * u), Size(11f * u, 6f * u), style = Stroke(sw))
            drawOval(c, Offset(10.5f * u, 9f * u), Size(11f * u, 6f * u), style = Stroke(sw))
        }
        Ic.Fx -> {
            ln(9f, 19f, 9f, 8f); ln(9f, 8f, 12f, 5.5f); ln(6f, 12f, 12f, 12f)
            ln(13f, 12f, 19f, 19f); ln(19f, 12f, 13f, 19f)
        }
        Ic.Mask -> { rs(4f, 4f, 20f, 20f); cs(12f, 12f, 4.5f) }
        Ic.Folder -> poly(3f, 6f, 10f, 6f, 12f, 9f, 21f, 9f, 21f, 19f, 3f, 19f)
        Ic.Trash -> {
            ln(4f, 7f, 20f, 7f); rs(6f, 7f, 18f, 20f); ln(10f, 4f, 14f, 4f)
            ln(10f, 10f, 10f, 17f); ln(14f, 10f, 14f, 17f)
        }
        Ic.Menu -> { ln(4f, 7f, 20f, 7f); ln(4f, 12f, 20f, 12f); ln(4f, 17f, 20f, 17f) }
        Ic.Sun -> {
            cs(12f, 12f, 4f)
            for (i in 0 until 8) {
                val a = i * PI.toFloat() / 4f
                ln(12f + 7f * cos(a), 12f + 7f * sin(a), 12f + 9.5f * cos(a), 12f + 9.5f * sin(a))
            }
        }
        Ic.Curves -> {
            rs(4f, 4f, 20f, 20f); poly(4f, 20f, 9f, 15f, 13f, 10f, 20f, 4f, close = false)
            ln(12f, 4f, 12f, 20f, 1f * u); ln(4f, 12f, 20f, 12f, 1f * u)
        }
        Ic.Levels -> {
            rf(4f, 14f, 7f, 20f); rf(8.5f, 8f, 11.5f, 20f); rf(13f, 11f, 16f, 20f); rf(17.5f, 5f, 20.5f, 20f)
        }
        Ic.Exposure -> {
            rs(4f, 4f, 20f, 20f); ln(4f, 20f, 20f, 4f)
            ln(6.5f, 8f, 10.5f, 8f); ln(8.5f, 6f, 8.5f, 10f); ln(13.5f, 16f, 17.5f, 16f)
        }
        Ic.Vibrance -> { poly(12f, 5f, 20f, 19f, 4f, 19f); poly(12f, 11f, 15.5f, 17f, 8.5f, 17f) }
        Ic.HueSat -> {
            rs(3f, 5f, 21f, 19f); ln(6f, 10f, 18f, 10f); ln(6f, 14f, 18f, 14f); cf(9f, 10f, 1.8f); cf(15f, 14f, 1.8f)
        }
        Ic.Balance -> {
            ln(12f, 4f, 12f, 20f); ln(5f, 8f, 19f, 8f)
            poly(5f, 8f, 2.5f, 14f, 7.5f, 14f); poly(19f, 8f, 16.5f, 14f, 21.5f, 14f); ln(8f, 20f, 16f, 20f)
        }
        Ic.Mixer -> { rs(4f, 4f, 20f, 20f); mountains(); cf(15.5f, 8.5f, 1.4f) }
        Ic.Camera -> { rs(3f, 8f, 21f, 19f); cs(12f, 13.5f, 3.5f); rf(8f, 5f, 12f, 8f) }
        Ic.GradMap -> {
            rs(4f, 4f, 20f, 20f)
            for (i in 0 until 4) {
                val y = 7f + i * 3.4f
                drawLine(c.copy(alpha = 0.3f + 0.2f * i), Offset(5f * u, y * u), Offset(19f * u, y * u), strokeWidth = 2.4f * u)
            }
        }
        Ic.Lookup -> {
            rs(4f, 4f, 20f, 20f); ln(9f, 4f, 9f, 20f, 1.2f * u); ln(14f, 4f, 14f, 20f, 1.2f * u)
            ln(4f, 9f, 20f, 9f, 1.2f * u); ln(4f, 14f, 20f, 14f, 1.2f * u)
        }
        Ic.Invert -> { rs(4f, 4f, 20f, 20f); poly(4f, 20f, 20f, 4f, 20f, 20f, fill = true) }
        Ic.Posterize -> poly(3f, 19f, 9f, 9f, 13f, 15f, 16f, 11f, 21f, 19f)
        Ic.Threshold -> {
            poly(3f, 19f, 8f, 10f, 11f, 15f, 14f, 6f, 17f, 13f, 21f, 19f); ln(3f, 21f, 21f, 21f, 1.2f * u)
        }
        Ic.FlipH -> { ln(12f, 3f, 12f, 21f, 1.4f * u); poly(10f, 7f, 4f, 17f, 10f, 17f); poly(14f, 7f, 20f, 17f, 14f, 17f) }
        Ic.FlipV -> { ln(3f, 12f, 21f, 12f, 1.4f * u); poly(6f, 10f, 18f, 10f, 12f, 4f); poly(6f, 14f, 18f, 14f, 12f, 20f) }
        Ic.AlignL -> { ln(4f, 3f, 4f, 21f); rf(6f, 6f, 18f, 10f); rf(6f, 14f, 13f, 18f) }
        Ic.AlignCH -> { ln(12f, 3f, 12f, 21f); rf(5f, 6f, 19f, 10f); rf(8f, 14f, 16f, 18f) }
        Ic.AlignR -> { ln(20f, 3f, 20f, 21f); rf(6f, 6f, 18f, 10f); rf(11f, 14f, 18f, 18f) }
        Ic.AlignT -> { ln(3f, 4f, 21f, 4f); rf(6f, 6f, 10f, 18f); rf(14f, 6f, 18f, 13f) }
        Ic.AlignMV -> { ln(3f, 12f, 21f, 12f); rf(6f, 5f, 10f, 19f); rf(14f, 8f, 18f, 16f) }
        Ic.AlignB -> { ln(3f, 20f, 21f, 20f); rf(6f, 6f, 10f, 18f); rf(14f, 11f, 18f, 18f) }
        Ic.DistA -> { ln(4f, 4f, 4f, 20f); ln(20f, 4f, 20f, 20f); rf(9f, 7f, 15f, 17f) }
        Ic.DistB -> { ln(4f, 4f, 4f, 20f); ln(20f, 4f, 20f, 20f); rf(8f, 7f, 11f, 17f); rf(13f, 7f, 16f, 17f) }
        Ic.DistC -> { ln(4f, 4f, 20f, 4f); ln(4f, 20f, 20f, 20f); rf(7f, 9f, 17f, 15f) }
        Ic.Angle -> {
            ln(4f, 19f, 20f, 19f); ln(4f, 19f, 16f, 9f)
            drawArc(c, -40f, 40f, false, Offset(-5f * u, 10f * u), Size(18f * u, 18f * u), style = Stroke(sw))
        }
    }
}
