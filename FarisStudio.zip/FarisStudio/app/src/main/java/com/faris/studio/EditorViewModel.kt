package com.faris.studio

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.IntSize
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.faris.studio.core.BlendKind
import com.faris.studio.core.BrushPreset
import com.faris.studio.core.ClearOp
import com.faris.studio.core.EditState
import com.faris.studio.core.Exporter
import com.faris.studio.core.FillOp
import com.faris.studio.core.FilterPreset
import com.faris.studio.core.Filters
import com.faris.studio.core.GradientOp
import com.faris.studio.core.Gradients
import com.faris.studio.core.ImageLoader
import com.faris.studio.core.MoveOp
import com.faris.studio.core.PaintLayer
import com.faris.studio.core.PaintOp
import com.faris.studio.core.PaintRenderer
import com.faris.studio.core.ShapeKind
import com.faris.studio.core.ShapeOp
import com.faris.studio.core.SpatialFx
import com.faris.studio.core.SpatialKind
import com.faris.studio.core.StrokeOp
import com.faris.studio.core.TextOp
import com.faris.studio.ui.Ic
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

enum class Tool(val label: String, val icon: Ic, val implemented: Boolean) {
    Marquee("Rectangular Marquee", Ic.Marquee, true),
    Move("Move", Ic.Move, true),
    Lasso("Lasso", Ic.Lasso, true),
    Wand("Magic Wand", Ic.Wand, false),
    Brush("Brush", Ic.Brush, true),
    Crop("Crop", Ic.Crop, false),
    Picker("Eyedropper", Ic.Eyedropper, true),
    Eraser("Eraser", Ic.Eraser, true),
    Gradient("Gradient", Ic.Gradient, true),
    Fill("Paint Bucket", Ic.Gradient, true),
    Blur("Blur", Ic.Drop, false),
    Heal("Healing", Ic.Healing, false),
    Pen("Pen", Ic.Pen, false),
    Text("Type", Ic.Type, true),
    PathSel("Path Selection", Ic.PathSel, false),
    Shape("Shape", Ic.Shape, true),
    Hand("Hand", Ic.Hand, true),
    Zoom("Zoom", Ic.Zoom, true);

    companion object {
        val rail = listOf(
            Marquee, Move, Lasso, Wand, Brush, Crop, Picker, Eraser, Gradient,
            Blur, Heal, Pen, Text, PathSel, Shape, Hand, Zoom
        )
    }
}

enum class SelMode { Rectangle, Ellipse }

class LiveLine(val a: Offset, val b: Offset)

class Command(val undo: () -> Unit, val redo: () -> Unit)

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    // ---------- Document ----------
    var bitmap by mutableStateOf<Bitmap?>(null); private set
    var processed by mutableStateOf<Bitmap?>(null); private set
    var processing by mutableStateOf(false); private set
    var thumb by mutableStateOf<Bitmap?>(null); private set
    var spatialThumbs by mutableStateOf<Map<SpatialKind, Bitmap>>(emptyMap()); private set
    var fileName by mutableStateOf(""); private set
    var loading by mutableStateOf(false); private set
    var message by mutableStateOf<String?>(null); private set

    // ---------- Viewport ----------
    var scale by mutableStateOf(1f); private set
    var offset by mutableStateOf(Offset.Zero); private set
    var rotation by mutableStateOf(0f); private set
    var canvasSize by mutableStateOf(IntSize.Zero)

    // ---------- Tools & options ----------
    var tool by mutableStateOf(Tool.Hand); private set
    var brushColor by mutableStateOf(0xFF000000.toInt())
    var bgColor by mutableStateOf(0xFFFFFFFF.toInt())
    var brushFrac by mutableStateOf(0.15f)
    var brushAlpha by mutableStateOf(1f)
    var brushSoft by mutableStateOf(0f)
    var shapeKind by mutableStateOf(ShapeKind.Rect)
    var shapeFilled by mutableStateOf(false)
    var selMode by mutableStateOf(SelMode.Rectangle)
    var gradIndex by mutableStateOf(0)
    var gradRadial by mutableStateOf(false)
    var activeTile by mutableStateOf<String?>(null)
    var zoomOut by mutableStateOf(false)
    var pendingTextPos by mutableStateOf<PointF?>(null)

    // ---------- Live (in-progress) overlays ----------
    var liveShape by mutableStateOf<ShapeOp?>(null); private set
    var liveSel by mutableStateOf<Path?>(null); private set
    var liveGrad by mutableStateOf<LiveLine?>(null); private set
    var liveMove by mutableStateOf(Offset.Zero); private set
    var pendingMove by mutableStateOf(Offset.Zero); private set

    // ---------- Edit, selection, layers ----------
    var edit by mutableStateOf(EditState()); private set
    var selection by mutableStateOf<Path?>(null); private set
    val layers = mutableStateListOf<PaintLayer>()
    var activeLayerId by mutableStateOf(-1); private set
    var bgVisible by mutableStateOf(true)
    var version by mutableIntStateOf(0); private set
    var commitVersion by mutableIntStateOf(0); private set

    private var nextId = 1
    private var layerCounter = 2
    private var editSnapshot: EditState? = null
    private var spatialJob: Job? = null
    private var spatialNow: SpatialKind? = null

    // ---------- History ----------
    private val undoStack = ArrayDeque<Command>()
    private val redoStack = ArrayDeque<Command>()
    private var historyVersion by mutableIntStateOf(0)
    val canUndo: Boolean get() = historyVersion >= 0 && undoStack.isNotEmpty()
    val canRedo: Boolean get() = historyVersion >= 0 && redoStack.isNotEmpty()

    val isDrawTool: Boolean
        get() = tool == Tool.Brush || tool == Tool.Eraser || tool == Tool.Shape ||
            tool == Tool.Marquee || tool == Tool.Lasso || tool == Tool.Gradient || tool == Tool.Move
    val isTapTool: Boolean
        get() = tool == Tool.Picker || tool == Tool.Text || tool == Tool.Fill || tool == Tool.Zoom
    val activeLayer: PaintLayer? get() = layers.firstOrNull { it.id == activeLayerId }

    fun toast(m: String) { message = m }
    fun dismissMessage() { message = null }

    fun selectTool(t: Tool) {
        if (!t.implemented) {
            toast("أداة «${t.label}» غير مفعّلة بعد، قريباً")
            return
        }
        if (tool == Tool.Move && t != Tool.Move) applyPending()
        tool = t
    }

    fun tileBitmap(p: FilterPreset): Bitmap? = p.spatial?.let { spatialThumbs[it] } ?: thumb

    // ---------- Open ----------
    fun openImage(uri: Uri) {
        loading = true
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val result = withContext(Dispatchers.IO) {
                try {
                    val bmp = ImageLoader.load(ctx, uri) ?: return@withContext null
                    val s = 160f / max(bmp.width, bmp.height)
                    val th = Bitmap.createScaledBitmap(
                        bmp, max(1, (bmp.width * s).toInt()), max(1, (bmp.height * s).toInt()), true
                    )
                    val sp = HashMap<SpatialKind, Bitmap>()
                    for (k in SpatialKind.values()) sp[k] = SpatialFx.apply(th, k)
                    Triple(bmp, Pair(th, sp as Map<SpatialKind, Bitmap>), ImageLoader.displayName(ctx, uri))
                } catch (e: Throwable) {
                    null
                }
            }
            loading = false
            if (result == null) {
                toast("تعذر فتح الصورة")
                return@launch
            }
            val (bmp, thumbs, name) = result
            try {
                newDocument(bmp)
            } catch (e: OutOfMemoryError) {
                toast("الذاكرة لا تكفي لهذه الصورة")
                return@launch
            }
            thumb = thumbs.first
            spatialThumbs = thumbs.second
            fileName = name
            fit()
        }
    }

    private fun newDocument(bmp: Bitmap) {
        val first = PaintLayer(nextId++, "Layer 1", bmp.width, bmp.height)
        spatialJob?.cancel()
        spatialNow = null
        processed = null
        processing = false
        bitmap = bmp
        layers.clear()
        layers.add(first)
        activeLayerId = first.id
        layerCounter = 2
        bgVisible = true
        edit = EditState()
        editSnapshot = null
        selection = null
        pendingTextPos = null
        undoStack.clear()
        redoStack.clear()
        historyVersion++
        version++
        commitVersion++
    }

    // ---------- Viewport ----------
    fun fit() {
        val b = bitmap ?: return
        if (canvasSize.width == 0 || canvasSize.height == 0) return
        scale = min(canvasSize.width / b.width.toFloat(), canvasSize.height / b.height.toFloat()) * 0.95f
        offset = Offset.Zero
        rotation = 0f
    }

    fun actualSize() { scale = 1f; offset = Offset.Zero }

    fun setZoom(pct: Int) {
        if (bitmap == null) return
        val target = (pct / 100f).coerceIn(MIN_SCALE, MAX_SCALE)
        transform(Offset(canvasSize.width / 2f, canvasSize.height / 2f), Offset.Zero, target / scale, 0f)
    }

    fun zoomStep(factor: Float) {
        transform(Offset(canvasSize.width / 2f, canvasSize.height / 2f), Offset.Zero, factor, 0f)
    }

    fun rotateView(deg: Float) {
        val rad = Math.toRadians(deg.toDouble())
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()
        offset = Offset(offset.x * c - offset.y * s, offset.x * s + offset.y * c)
        rotation = (rotation + deg) % 360f
    }

    fun transform(centroid: Offset, pan: Offset, zoom: Float, rotDeg: Float) {
        val center = Offset(canvasSize.width / 2f, canvasSize.height / 2f)
        val newScale = (scale * zoom).coerceIn(MIN_SCALE, MAX_SCALE)
        val z = newScale / scale
        val rad = Math.toRadians(rotDeg.toDouble())
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()
        val v = center + offset - centroid
        val rx = (v.x * c - v.y * s) * z
        val ry = (v.x * s + v.y * c) * z
        offset = centroid - center + Offset(rx, ry) + pan
        scale = newScale
        rotation = (rotation + rotDeg) % 360f
    }

    fun screenToImage(p: Offset): Offset {
        val b = bitmap ?: return p
        val c = Offset(canvasSize.width / 2f, canvasSize.height / 2f)
        val v = p - c - offset
        val rad = Math.toRadians(-rotation.toDouble())
        val cs = cos(rad).toFloat()
        val sn = sin(rad).toFloat()
        val rx = v.x * cs - v.y * sn
        val ry = v.x * sn + v.y * cs
        return Offset(rx / scale + b.width / 2f, ry / scale + b.height / 2f)
    }

    // ---------- History ----------
    private fun push(c: Command) {
        undoStack.addLast(c)
        if (undoStack.size > 60) undoStack.removeFirst()
        redoStack.clear()
        historyVersion++
        commitVersion++
    }

    fun undo() {
        cancelPending()
        val c = undoStack.removeLastOrNull() ?: return
        c.undo()
        redoStack.addLast(c)
        historyVersion++
        version++
        commitVersion++
    }

    fun redo() {
        cancelPending()
        val c = redoStack.removeLastOrNull() ?: return
        c.redo()
        undoStack.addLast(c)
        historyVersion++
        version++
        commitVersion++
    }

    // ---------- Filters / adjustments ----------
    private fun applyEdit(e: EditState) {
        edit = e
        refreshSpatial()
    }

    private fun refreshSpatial() {
        val want = Filters.spatialOf(edit.filterId)
        if (want == spatialNow) return
        spatialNow = want
        spatialJob?.cancel()
        val base = bitmap
        if (want == null || base == null) {
            processed = null
            processing = false
            return
        }
        processing = true
        spatialJob = viewModelScope.launch {
            val out = withContext(Dispatchers.Default) {
                try { SpatialFx.apply(base, want) } catch (t: Throwable) { null }
            }
            if (spatialNow == want) {
                processed = out
                processing = false
                if (out == null) toast("الذاكرة لا تكفي لهذا الفلتر")
            }
        }
    }

    fun setEditNow(n: EditState) {
        val before = edit
        if (before == n) return
        applyEdit(n)
        push(Command({ applyEdit(before) }, { applyEdit(n) }))
    }

    fun setFilter(id: String) = setEditNow(edit.copy(filterId = id))

    fun previewEdit(n: EditState) {
        if (editSnapshot == null) editSnapshot = edit
        applyEdit(n)
    }

    fun commitPreview() {
        val s = editSnapshot ?: return
        editSnapshot = null
        val after = edit
        if (s != after) push(Command({ applyEdit(s) }, { applyEdit(after) }))
    }

    fun resetEdits() = setEditNow(EditState())

    // ---------- Colors & brushes ----------
    fun swapColors() { val t = brushColor; brushColor = bgColor; bgColor = t }

    fun selectBrushPreset(p: BrushPreset) {
        brushFrac = p.sizeFrac
        brushSoft = p.soft
        brushAlpha = p.alpha
        tool = Tool.Brush
    }

    // ---------- Layers ----------
    fun selectLayer(id: Int) { applyPending(); activeLayerId = id }

    fun toggleBackground() { bgVisible = !bgVisible }

    fun addLayer() {
        applyPending()
        val b = bitmap ?: return
        try {
            val l = PaintLayer(nextId++, "Layer ${layerCounter++}", b.width, b.height)
            val prev = activeLayerId
            layers.add(l)
            activeLayerId = l.id
            push(Command(
                undo = {
                    layers.remove(l)
                    activeLayerId = if (prev == -1 || layers.any { it.id == prev }) prev else (layers.lastOrNull()?.id ?: -1)
                },
                redo = { layers.add(l); activeLayerId = l.id }
            ))
        } catch (e: OutOfMemoryError) {
            toast("الذاكرة لا تكفي لطبقة جديدة")
        }
    }

    fun duplicateLayer() {
        applyPending()
        val src = activeLayer
        val b = bitmap
        if (src == null || b == null) { toast("اختر طبقة رسم أولاً"); return }
        try {
            val l = PaintLayer(nextId++, src.name + " copy", b.width, b.height)
            l.ops.addAll(src.ops)
            l.opacity = src.opacity
            l.blend = src.blend
            l.mx = src.mx
            l.my = src.my
            PaintRenderer.redraw(l)
            val idx = layers.indexOf(src) + 1
            layers.add(idx, l)
            activeLayerId = l.id
            push(Command(
                undo = { layers.remove(l); activeLayerId = src.id },
                redo = { layers.add(min(idx, layers.size), l); activeLayerId = l.id }
            ))
        } catch (e: OutOfMemoryError) {
            toast("الذاكرة لا تكفي لنسخ الطبقة")
        }
    }

    fun deleteActiveLayer() {
        cancelPending()
        val l = activeLayer
        if (l == null) { toast("لا يمكن حذف الخلفية"); return }
        val idx = layers.indexOf(l)
        layers.removeAt(idx)
        activeLayerId = layers.lastOrNull()?.id ?: -1
        version++
        push(Command(
            undo = { layers.add(min(idx, layers.size), l); activeLayerId = l.id },
            redo = { layers.remove(l); activeLayerId = layers.lastOrNull()?.id ?: -1 }
        ))
    }

    // ---------- Selection ----------
    private fun copyPath(p: Path?): Path? = p?.let { Path(it) }

    private fun commitSelection(n: Path?) {
        val before = copyPath(selection)
        val after = copyPath(n)
        selection = n
        push(Command({ selection = copyPath(before) }, { selection = copyPath(after) }))
    }

    fun selectAll() {
        val b = bitmap ?: return
        val p = Path()
        p.addRect(0f, 0f, b.width.toFloat(), b.height.toFloat(), Path.Direction.CW)
        commitSelection(p)
    }

    fun deselect() { if (selection != null) commitSelection(null) }

    fun invertSelection() {
        val s = selection
        if (s == null) { toast("لا يوجد تحديد"); return }
        val n = Path(s)
        n.toggleInverseFillType()
        commitSelection(n)
    }

    private fun buildSel(a: Offset, b: Offset): Path {
        val path = Path()
        if (tool == Tool.Lasso) {
            if (lassoPts.isNotEmpty()) {
                path.moveTo(lassoPts[0].x, lassoPts[0].y)
                for (i in 1 until lassoPts.size) path.lineTo(lassoPts[i].x, lassoPts[i].y)
                path.close()
            }
        } else {
            val l = min(a.x, b.x)
            val t = min(a.y, b.y)
            val r = max(a.x, b.x)
            val bt = max(a.y, b.y)
            if (selMode == SelMode.Ellipse) path.addOval(RectF(l, t, r, bt), Path.Direction.CW)
            else path.addRect(l, t, r, bt, Path.Direction.CW)
        }
        return path
    }

    // ---------- Drawing ----------
    private var drawing = false
    private var drawingLayer: PaintLayer? = null
    private var curCanvas: Canvas? = null
    private var curPaint: Paint? = null
    private var curClip: Path? = null
    private var strokePts = ArrayList<PointF>()
    private var lastPt: Offset? = null
    private var startPt: Offset? = null
    private var endPt: Offset? = null
    private val lassoPts = ArrayList<Offset>()

    private fun maxDim(): Float {
        val b = bitmap ?: return 1000f
        return max(b.width, b.height).toFloat()
    }

    fun curSize(): Float = maxDim() * (0.002f + brushFrac * 0.08f)
    private fun alphaInt(): Int = (brushAlpha * 255f).toInt().coerceIn(1, 255)

    private fun drawableLayer(): PaintLayer? {
        if (bitmap == null) return null
        val l = activeLayer
        if (l == null) { toast("اختر طبقة رسم (Layer) أولاً، الخلفية للقراءة فقط"); return null }
        if (!l.visible) { toast("الطبقة مخفية"); return null }
        if (l.locked || l.lockPixels) { toast("الطبقة مقفلة"); return null }
        return l
    }

    private fun movableLayer(): PaintLayer? {
        if (bitmap == null) return null
        val l = activeLayer
        if (l == null) { toast("اختر طبقة رسم، الخلفية لا تتحرك"); return null }
        if (!l.visible) { toast("الطبقة مخفية"); return null }
        if (l.locked || l.lockPos) { toast("موضع الطبقة مقفل"); return null }
        return l
    }

    private fun makeShape(a: Offset, b: Offset, clip: Path?) = ShapeOp(
        shapeKind, a.x, a.y, b.x, b.y, brushColor, curSize(), alphaInt(), shapeFilled, clip
    )

    private fun gradientColors(): IntArray {
        val g = Gradients.list[gradIndex.coerceIn(0, Gradients.list.size - 1)]
        val c = g.colors
        return if (c == null) intArrayOf(brushColor, bgColor) else IntArray(c.size) { c[it].toInt() }
    }

    fun beginDraw(screen: Offset) {
        drawing = false
        drawingLayer = null
        if (tool != Tool.Move && pendingMove != Offset.Zero) applyPending()
        val p = screenToImage(screen)
        startPt = p
        endPt = p
        when (tool) {
            Tool.Marquee, Tool.Lasso -> {
                lassoPts.clear()
                lassoPts.add(p)
                liveSel = buildSel(p, p)
                drawing = true
            }
            Tool.Brush, Tool.Eraser, Tool.Shape, Tool.Gradient, Tool.Move -> {
                val layer = (if (tool == Tool.Move) movableLayer() else drawableLayer()) ?: return
                drawingLayer = layer
                drawing = true
                curClip = copyPath(selection)
                when (tool) {
                    Tool.Brush, Tool.Eraser -> {
                        strokePts = arrayListOf(PointF(p.x, p.y))
                        lastPt = p
                        val paint = PaintRenderer.strokePaint(brushColor, curSize(), alphaInt(), tool == Tool.Eraser, brushSoft)
                        val canvas = Canvas(layer.bitmap)
                        val clip = curClip
                        if (clip != null) canvas.clipPath(clip)
                        curPaint = paint
                        curCanvas = canvas
                        canvas.drawPoint(p.x, p.y, paint)
                        version++
                    }
                    Tool.Shape -> liveShape = makeShape(p, p, null)
                    Tool.Gradient -> liveGrad = LiveLine(p, p)
                    Tool.Move -> liveMove = Offset.Zero
                    else -> {}
                }
            }
            else -> {}
        }
    }

    fun drawTo(screen: Offset) {
        if (!drawing) return
        val p = screenToImage(screen)
        endPt = p
        when (tool) {
            Tool.Marquee, Tool.Lasso -> {
                lassoPts.add(p)
                liveSel = buildSel(startPt ?: p, p)
            }
            Tool.Brush, Tool.Eraser -> {
                val l = lastPt ?: return
                val c = curCanvas ?: return
                val paint = curPaint ?: return
                c.drawLine(l.x, l.y, p.x, p.y, paint)
                strokePts.add(PointF(p.x, p.y))
                lastPt = p
                version++
            }
            Tool.Shape -> liveShape = makeShape(startPt ?: p, p, null)
            Tool.Gradient -> liveGrad = LiveLine(startPt ?: p, p)
            Tool.Move -> liveMove = p - (startPt ?: p)
            else -> {}
        }
    }

    fun endDraw() {
        if (!drawing) { clearDrawState(); return }
        val layer = drawingLayer
        val s = startPt
        val e = endPt
        when (tool) {
            Tool.Marquee, Tool.Lasso -> {
                val path = liveSel
                val dragged = if (s != null && e != null) hypot(e.x - s.x, e.y - s.y) * scale > 6f else false
                val big = if (tool == Tool.Lasso) lassoPts.size > 3 && dragged else dragged
                if (big && path != null) commitSelection(path) else if (selection != null) commitSelection(null)
            }
            Tool.Brush, Tool.Eraser -> if (layer != null) {
                val eraser = tool == Tool.Eraser
                val op = StrokeOp(strokePts.toList(), brushColor, curSize(), alphaInt(), eraser, brushSoft, curClip)
                commitOp(layer, op, redraw = !eraser && (op.alpha < 255 || brushSoft > 0.05f))
            }
            Tool.Shape -> if (layer != null) {
                val sh = liveShape
                if (sh != null && hypot(sh.x2 - sh.x1, sh.y2 - sh.y1) > 3f) {
                    val op = makeShape(Offset(sh.x1, sh.y1), Offset(sh.x2, sh.y2), curClip)
                    PaintRenderer.apply(layer, op)
                    commitOp(layer, op)
                }
            }
            Tool.Gradient -> if (layer != null) {
                val g = liveGrad
                if (g != null && hypot(g.b.x - g.a.x, g.b.y - g.a.y) > 3f) {
                    val op = GradientOp(g.a.x, g.a.y, g.b.x, g.b.y, gradientColors(), gradRadial, alphaInt(), curClip)
                    PaintRenderer.apply(layer, op)
                    commitOp(layer, op)
                }
            }
            Tool.Move -> if (layer != null) { pendingMove += liveMove }
            else -> {}
        }
        clearDrawState()
    }

    fun cancelDraw() {
        val layer = drawingLayer
        if (layer != null && (tool == Tool.Brush || tool == Tool.Eraser)) {
            PaintRenderer.redraw(layer)
            version++
        }
        clearDrawState()
    }

    private fun clearDrawState() {
        drawing = false
        drawingLayer = null
        curCanvas = null
        curPaint = null
        curClip = null
        lastPt = null
        startPt = null
        endPt = null
        liveShape = null
        liveSel = null
        liveGrad = null
        liveMove = Offset.Zero
        strokePts = ArrayList()
        lassoPts.clear()
    }

    private fun commitOp(
        layer: PaintLayer, op: PaintOp, redraw: Boolean = false,
        onUndo: () -> Unit = {}, onRedo: () -> Unit = {}
    ) {
        layer.ops.add(op)
        if (redraw) PaintRenderer.redraw(layer)
        version++
        push(Command(
            undo = {
                if (layer.ops.isNotEmpty()) layer.ops.removeAt(layer.ops.lastIndex)
                PaintRenderer.redraw(layer)
                onUndo()
            },
            redo = {
                layer.ops.add(op)
                PaintRenderer.apply(layer, op)
                onRedo()
            }
        ))
    }

    fun applyPending() {
        val p = pendingMove
        pendingMove = Offset.Zero
        val layer = activeLayer ?: return
        val dx = p.x.roundToInt()
        val dy = p.y.roundToInt()
        if (dx == 0 && dy == 0) return
        val op = MoveOp(dx, dy)
        PaintRenderer.apply(layer, op)
        layer.mx += dx
        layer.my += dy
        commitOp(layer, op,
            onUndo = { layer.mx -= dx; layer.my -= dy },
            onRedo = { layer.mx += dx; layer.my += dy })
    }

    fun cancelPending() { pendingMove = Offset.Zero }

    private fun layerBounds(l: PaintLayer): RectF? {
        val bmp = l.bitmap
        val w = bmp.width
        val h = bmp.height
        val row = IntArray(w)
        var minX = w
        var maxX = -1
        var minY = h
        var maxY = -1
        for (y in 0 until h) {
            bmp.getPixels(row, 0, w, 0, y, w, 1)
            var any = false
            for (x in 0 until w) {
                if ((row[x] ushr 24) != 0) {
                    any = true
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                }
            }
            if (any) {
                if (y < minY) minY = y
                if (y > maxY) maxY = y
            }
        }
        return if (maxX < 0) null else RectF(minX.toFloat(), minY.toFloat(), (maxX + 1).toFloat(), (maxY + 1).toFloat())
    }

    /** kind: 0 left, 1 h-center, 2 right, 3 top, 4 v-middle, 5 bottom. */
    fun alignActive(kind: Int) {
        val b = bitmap ?: return
        val layer = movableLayer() ?: return
        val r = layerBounds(layer)
        if (r == null) { toast("الطبقة فارغة"); return }
        val w = b.width.toFloat()
        val h = b.height.toFloat()
        var px = pendingMove.x
        var py = pendingMove.y
        when (kind) {
            0 -> px = -r.left
            1 -> px = w / 2f - (r.left + r.right) / 2f
            2 -> px = w - r.right
            3 -> py = -r.top
            4 -> py = h / 2f - (r.top + r.bottom) / 2f
            else -> py = h - r.bottom
        }
        pendingMove = Offset(px, py)
    }

    fun fillLayer() {
        val layer = drawableLayer() ?: return
        val op = FillOp(brushColor, activeTile, max(1f, maxDim() / 800f), alphaInt(), copyPath(selection))
        PaintRenderer.apply(layer, op)
        commitOp(layer, op)
    }

    fun clearSelectionContent() {
        val layer = drawableLayer() ?: return
        val op = ClearOp(copyPath(selection))
        PaintRenderer.apply(layer, op)
        commitOp(layer, op)
    }

    fun tap(screen: Offset) {
        val b = bitmap ?: return
        when (tool) {
            Tool.Zoom -> { transform(screen, Offset.Zero, if (zoomOut) 0.6f else 1.6f, 0f); return }
            Tool.Fill -> { fillLayer(); return }
            else -> {}
        }
        val p = screenToImage(screen)
        val x = p.x.toInt()
        val y = p.y.toInt()
        if (x < 0 || y < 0 || x >= b.width || y >= b.height) return
        when (tool) {
            Tool.Picker -> {
                var color = 0
                var found = false
                for (l in layers.asReversed()) {
                    if (!l.visible) continue
                    val px = l.bitmap.getPixel(x, y)
                    if (android.graphics.Color.alpha(px) > 0) { color = px; found = true; break }
                }
                if (!found) color = b.getPixel(x, y)
                brushColor = color or (0xFF shl 24)
                toast("تم التقاط اللون")
            }
            Tool.Text -> if (drawableLayer() != null) pendingTextPos = PointF(p.x, p.y)
            else -> {}
        }
    }

    fun confirmText(text: String) {
        val pos = pendingTextPos
        pendingTextPos = null
        val t = text.trim()
        if (pos == null || t.isEmpty()) return
        val layer = drawableLayer() ?: return
        val op = TextOp(t, pos.x, pos.y, brushColor, curSize() * 3f, alphaInt(), copyPath(selection))
        PaintRenderer.apply(layer, op)
        commitOp(layer, op)
    }

    // ---------- Export ----------
    private var saving = false

    fun exportPng() {
        applyPending()
        val base = processed ?: bitmap
        if (base == null) { toast("افتح صورة أولاً"); return }
        if (saving) return
        saving = true
        val e = edit
        val ls = layers.toList()
        val bgVis = bgVisible
        toast("جارٍ الحفظ…")
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val res = withContext(Dispatchers.IO) {
                try {
                    val out = composeBitmap(base, e, ls, bgVis)
                    val r = Exporter.savePng(ctx, out, "FARIS_${System.currentTimeMillis()}")
                    out.recycle()
                    r
                } catch (t: Throwable) {
                    null
                }
            }
            saving = false
            toast(if (res != null) "تم الحفظ: $res" else "فشل الحفظ")
        }
    }

    private fun composeBitmap(base: Bitmap, e: EditState, ls: List<PaintLayer>, bgVis: Boolean): Bitmap {
        val out = Bitmap.createBitmap(base.width, base.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        if (bgVis) {
            val p = Paint(Paint.FILTER_BITMAP_FLAG)
            p.colorFilter = ColorMatrixColorFilter(Filters.finalMatrix(e))
            c.drawBitmap(base, 0f, 0f, p)
            if (e.vignette > 0) {
                c.drawRect(0f, 0f, base.width.toFloat(), base.height.toFloat(),
                    Filters.vignettePaint(base.width, base.height, e.vignette))
            }
        }
        for (l in ls) {
            if (!l.visible) continue
            val lp = Paint(Paint.FILTER_BITMAP_FLAG)
            lp.alpha = (l.opacity * 255f).toInt().coerceIn(0, 255)
            val mode = l.blend.pd
            if (mode != null) lp.xfermode = PorterDuffXfermode(mode)
            c.drawBitmap(l.bitmap, 0f, 0f, lp)
        }
        return out
    }

    companion object {
        const val MIN_SCALE = 0.02f
        const val MAX_SCALE = 64f
    }
}
