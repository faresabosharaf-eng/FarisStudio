package com.faris.studio

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.IntSize
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.faris.studio.core.ImageLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

enum class Tool { Hand, Zoom }

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    // ---- Document ----
    var bitmap by mutableStateOf<Bitmap?>(null); private set
    var fileName by mutableStateOf(""); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set

    // ---- Viewport (Canvas Engine, stage 2) ----
    var scale by mutableStateOf(1f); private set
    var offset by mutableStateOf(Offset.Zero); private set
    var rotation by mutableStateOf(0f); private set
    var canvasSize by mutableStateOf(IntSize.Zero)

    var tool by mutableStateOf(Tool.Hand)

    fun openImage(uri: Uri) {
        loading = true
        error = null
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val result = withContext(Dispatchers.IO) {
                try {
                    ImageLoader.load(ctx, uri)?.let { it to ImageLoader.displayName(ctx, uri) }
                } catch (e: OutOfMemoryError) {
                    null
                } catch (e: Exception) {
                    null
                }
            }
            loading = false
            if (result == null) {
                error = "تعذر فتح الصورة / Could not open image"
            } else {
                bitmap = result.first
                fileName = result.second
                fit()
            }
        }
    }

    fun fit() {
        val b = bitmap ?: return
        if (canvasSize.width == 0 || canvasSize.height == 0) return
        scale = min(canvasSize.width / b.width.toFloat(), canvasSize.height / b.height.toFloat()) * 0.95f
        offset = Offset.Zero
        rotation = 0f
    }

    fun actualSize() {
        scale = 1f
        offset = Offset.Zero
    }

    fun zoomStep(factor: Float) {
        val c = Offset(canvasSize.width / 2f, canvasSize.height / 2f)
        transform(c, Offset.Zero, factor, 0f)
    }

    fun rotateView(deg: Float) {
        val rad = Math.toRadians(deg.toDouble())
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()
        offset = Offset(offset.x * c - offset.y * s, offset.x * s + offset.y * c)
        rotation = (rotation + deg) % 360f
    }

    /** Applies a pan/zoom/rotate gesture about [centroid] (screen coordinates). */
    fun transform(centroid: Offset, pan: Offset, zoom: Float, rotDeg: Float) {
        val center = Offset(canvasSize.width / 2f, canvasSize.height / 2f)
        val newScale = (scale * zoom).coerceIn(MIN_SCALE, MAX_SCALE)
        val z = newScale / scale
        val rad = Math.toRadians(rotDeg.toDouble())
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()
        val v = center + offset - centroid
        val rx = (v.x * c - v.y * s) * z
        val ry = (v.x * s + v.y * c) * z
        offset = centroid - center + Offset(rx, ry) + pan
        scale = newScale
        rotation = (rotation + rotDeg) % 360f
    }

    companion object {
        const val MIN_SCALE = 0.02f
        const val MAX_SCALE = 64f
    }
}
