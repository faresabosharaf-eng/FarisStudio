package com.faris.studio.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.faris.studio.EditorViewModel
import com.faris.studio.core.BlendKind
import kotlin.math.roundToInt

enum class Adj(val label: String, val icon: Ic, val implemented: Boolean) {
    BrightContrast("Brightness / Contrast", Ic.Sun, true),
    Curves("Curves", Ic.Curves, false),
    Levels("Levels", Ic.Levels, true),
    Exposure("Exposure", Ic.Exposure, true),
    Vibrance("Vibrance", Ic.Vibrance, false),
    HueSat("Hue / Saturation", Ic.HueSat, true),
    ColorBalance("Color Balance", Ic.Balance, true),
    BlackWhite("Black & White", Ic.BW, true),
    ChannelMixer("Channel Mixer", Ic.Mixer, false),
    PhotoFilter("Photo Filter", Ic.Camera, true),
    GradientMap("Gradient Map", Ic.GradMap, false),
    ColorLookup("Color Lookup", Ic.Lookup, false),
    Invert("Invert", Ic.Invert, true),
    Posterize("Posterize", Ic.Posterize, false),
    Threshold("Threshold", Ic.Threshold, false)
}

@Composable
fun LabeledSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String,
    onChange: (Float) -> Unit, onDone: () -> Unit = {}, modifier: Modifier = Modifier
) {
    Column(modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 13.sp, color = TextDim)
            Text(valueText, fontSize = 13.sp)
        }
        Slider(
            value = value, onValueChange = onChange, onValueChangeFinished = onDone, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
        )
    }
}

@Composable
fun MiniSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String,
    onChange: (Float) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = TextDim)
        Slider(
            value = value, onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent),
            modifier = Modifier.width(110.dp)
        )
        Text(valueText, fontSize = 13.sp)
    }
}

/** Bordered drop-down button like the ones in the design. */
@Composable
fun DropPick(
    text: String, items: List<String>, enabled: Boolean = true,
    minWidth: Dp = 0.dp, onDisabled: () -> Unit = {}, onPick: (Int) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier
                .alpha(if (enabled) 1f else 0.45f)
                .defaultMinSize(minWidth = minWidth)
                .border(1.dp, Line, RoundedCornerShape(6.dp))
                .clickable { if (enabled) open = true else onDisabled() }
                .padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text, fontSize = 14.sp, maxLines = 1)
            Spacer(Modifier.width(8.dp))
            FIcon(Ic.Chevron, size = 14.dp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            items.forEachIndexed { i, s ->
                DropdownMenuItem(text = { Text(s, fontSize = 14.sp) }, onClick = { open = false; onPick(i) })
            }
        }
    }
}

@Composable
fun AdjustDialogBody(vm: EditorViewModel, adj: Adj) {
    val e = vm.edit
    Column {
        when (adj) {
            Adj.BrightContrast -> {
                LabeledSlider("Brightness", e.brightness.toFloat(), -100f..100f, "${e.brightness}",
                    { vm.previewEdit(vm.edit.copy(brightness = it.roundToInt())) }, { vm.commitPreview() })
                LabeledSlider("Contrast", e.contrast.toFloat(), -100f..100f, "${e.contrast}",
                    { vm.previewEdit(vm.edit.copy(contrast = it.roundToInt())) }, { vm.commitPreview() })
            }
            Adj.Levels -> {
                LabeledSlider("Input black", e.levelsLo.toFloat(), 0f..250f, "${e.levelsLo}",
                    { vm.previewEdit(vm.edit.copy(levelsLo = it.roundToInt().coerceAtMost(vm.edit.levelsHi - 5))) },
                    { vm.commitPreview() })
                LabeledSlider("Input white", e.levelsHi.toFloat(), 5f..255f, "${e.levelsHi}",
                    { vm.previewEdit(vm.edit.copy(levelsHi = it.roundToInt().coerceAtLeast(vm.edit.levelsLo + 5))) },
                    { vm.commitPreview() })
            }
            Adj.Exposure -> {
                LabeledSlider("Exposure", e.exposure.toFloat(), -100f..100f, "${e.exposure}",
                    { vm.previewEdit(vm.edit.copy(exposure = it.roundToInt())) }, { vm.commitPreview() })
            }
            Adj.HueSat -> {
                LabeledSlider("Hue", e.hue.toFloat(), -180f..180f, "${e.hue}",
                    { vm.previewEdit(vm.edit.copy(hue = it.roundToInt())) }, { vm.commitPreview() })
                LabeledSlider("Saturation", e.saturation.toFloat(), -100f..100f, "${e.saturation}",
                    { vm.previewEdit(vm.edit.copy(saturation = it.roundToInt())) }, { vm.commitPreview() })
            }
            Adj.ColorBalance -> {
                LabeledSlider("Red", e.balR.toFloat(), -100f..100f, "${e.balR}",
                    { vm.previewEdit(vm.edit.copy(balR = it.roundToInt())) }, { vm.commitPreview() })
                LabeledSlider("Green", e.balG.toFloat(), -100f..100f, "${e.balG}",
                    { vm.previewEdit(vm.edit.copy(balG = it.roundToInt())) }, { vm.commitPreview() })
                LabeledSlider("Blue", e.balB.toFloat(), -100f..100f, "${e.balB}",
                    { vm.previewEdit(vm.edit.copy(balB = it.roundToInt())) }, { vm.commitPreview() })
            }
            Adj.PhotoFilter -> {
                LabeledSlider("Cool / Warm", e.tint.toFloat(), -100f..100f, "${e.tint}",
                    { vm.previewEdit(vm.edit.copy(tint = it.roundToInt())) }, { vm.commitPreview() })
            }
            else -> {}
        }
    }
}

@Composable
private fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(BarBg), content = content)
}

@Composable
private fun CardHeader(title: String, menu: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp))
        Spacer(Modifier.weight(1f))
        menu()
    }
}

@Composable
private fun LockBtn(ic: Ic, active: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(32.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .border(if (active) 1.5.dp else 0.dp, if (active) Accent else Color.Transparent, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { FIcon(ic, size = 19.dp, tint = if (active) Accent else Color.White) }
}

@Composable
private fun LayerRow(
    name: String, thumbBitmap: android.graphics.Bitmap?, visible: Boolean, selected: Boolean,
    locked: Boolean, onToggle: () -> Unit, onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (selected) Selected else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(30.dp).alpha(if (visible) 1f else 0.3f).clickable(onClick = onToggle), contentAlignment = Alignment.Center) {
            FIcon(Ic.Eye, size = 22.dp)
        }
        Spacer(Modifier.width(8.dp))
        Box(Modifier.size(width = 56.dp, height = 40.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF2A3350))) {
            if (thumbBitmap != null) {
                Image(
                    bitmap = thumbBitmap.asImageBitmap(), contentDescription = null,
                    contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Text(name, fontSize = 15.sp, modifier = Modifier.weight(1f), maxLines = 1)
        if (locked) FIcon(Ic.LockAll, size = 18.dp, tint = TextDim)
    }
}

@Composable
fun LayersPanel(vm: EditorViewModel) {
    @Suppress("UNUSED_VARIABLE")
    val cv = vm.commitVersion // refresh thumbnails after each committed change
    val active = vm.activeLayer
    var menuOpen by remember { mutableStateOf(false) }
    var opOpen by remember { mutableStateOf(false) }
    val soon: (String) -> Unit = { vm.toast("$it قريباً") }
    val dim = TextDim.copy(alpha = 0.55f)

    PanelCard {
        CardHeader("Layers") {
            Text("Channels", fontSize = 15.sp, color = dim, modifier = Modifier.clickable { soon("Channels") }.padding(8.dp))
            Text("Paths", fontSize = 15.sp, color = dim, modifier = Modifier.clickable { soon("Paths") }.padding(8.dp))
            Box {
                Box(Modifier.size(36.dp).clickable { menuOpen = true }, contentAlignment = Alignment.Center) {
                    FIcon(Ic.Menu, size = 22.dp, tint = TextDim)
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(text = { Text("New Layer") }, onClick = { menuOpen = false; vm.addLayer() })
                    DropdownMenuItem(text = { Text("Duplicate Layer") }, onClick = { menuOpen = false; vm.duplicateLayer() })
                    DropdownMenuItem(text = { Text("Delete Layer") }, onClick = { menuOpen = false; vm.deleteActiveLayer() })
                }
            }
        }
        // Kind filter row
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                Modifier.alpha(0.55f).border(1.dp, Line, RoundedCornerShape(6.dp))
                    .clickable { soon("Kind") }.padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FIcon(Ic.Search, size = 18.dp)
                Spacer(Modifier.width(4.dp))
                Text("Kind", fontSize = 14.sp)
                Spacer(Modifier.width(4.dp))
                FIcon(Ic.Chevron, size = 14.dp)
            }
            listOf(Ic.KindImage, Ic.KindAdj, Ic.KindType, Ic.KindShape, Ic.KindSmart).forEach {
                Box(Modifier.alpha(0.55f).clickable { soon("Kind filter") }.padding(2.dp)) { FIcon(it, size = 20.dp) }
            }
        }
        // Blend + opacity
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            DropPick(
                text = active?.blend?.label ?: "Normal",
                items = BlendKind.values().map { it.label },
                enabled = active != null, minWidth = 96.dp,
                onDisabled = { vm.toast("الخلفية لا تدعم أنماط الدمج") }
            ) { i -> active?.blend = BlendKind.values()[i] }
            Spacer(Modifier.width(8.dp))
            Text("Opacity:", fontSize = 13.sp, color = TextDim)
            Spacer(Modifier.width(6.dp))
            Box {
                Row(
                    Modifier.alpha(if (active != null) 1f else 0.45f)
                        .border(1.dp, Line, RoundedCornerShape(6.dp))
                        .clickable { if (active != null) opOpen = true else vm.toast("الخلفية لا تدعم الشفافية") }
                        .padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${((active?.opacity ?: 1f) * 100).roundToInt()}%", fontSize = 14.sp)
                    Spacer(Modifier.width(6.dp))
                    FIcon(Ic.Chevron, size = 14.dp)
                }
                DropdownMenu(expanded = opOpen, onDismissRequest = { opOpen = false }) {
                    Box(Modifier.width(220.dp).padding(horizontal = 14.dp)) {
                        Slider(
                            value = active?.opacity ?: 1f,
                            onValueChange = { active?.opacity = it },
                            colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
                        )
                    }
                }
            }
        }
        // Lock + fill
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Lock:", fontSize = 13.sp, color = TextDim)
            Spacer(Modifier.width(6.dp))
            LockBtn(Ic.LockTransp, false, false) { soon("Lock transparent pixels") }
            LockBtn(Ic.LockPixels, active?.lockPixels == true, active != null) { active?.let { it.lockPixels = !it.lockPixels } }
            LockBtn(Ic.LockPos, active?.lockPos == true, active != null) { active?.let { it.lockPos = !it.lockPos } }
            LockBtn(Ic.LockAll, active?.locked == true, active != null) { active?.let { it.locked = !it.locked } }
            Spacer(Modifier.weight(1f))
            Text("Fill:", fontSize = 13.sp, color = TextDim)
            Spacer(Modifier.width(6.dp))
            Row(
                Modifier.alpha(0.45f).border(1.dp, Line, RoundedCornerShape(6.dp))
                    .clickable { soon("Fill") }.padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("100%", fontSize = 14.sp)
                Spacer(Modifier.width(6.dp))
                FIcon(Ic.Chevron, size = 14.dp)
            }
        }
        Spacer(Modifier.height(6.dp))
        vm.layers.asReversed().forEach { l ->
            LayerRow(l.name, l.bitmap, l.visible, vm.activeLayerId == l.id, l.locked || l.lockPixels || l.lockPos,
                onToggle = { l.visible = !l.visible }, onClick = { vm.selectLayer(l.id) })
        }
        LayerRow("Background", vm.thumb, vm.bgVisible, vm.activeLayerId == -1, true,
            onToggle = { vm.toggleBackground() }, onClick = { vm.selectLayer(-1) })
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp, horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            listOf(Ic.Link to "Link layers", Ic.Fx to "Layer styles", Ic.Mask to "Layer mask",
                Ic.AdjLayer to "Adjustment layer", Ic.Folder to "Group").forEach { (ic, name) ->
                Box(Modifier.alpha(0.55f).clickable { soon(name) }.padding(6.dp)) { FIcon(ic, size = 22.dp) }
            }
            Box(Modifier.clickable { vm.deleteActiveLayer() }.padding(6.dp)) { FIcon(Ic.Trash, size = 22.dp) }
        }
    }
}

@Composable
fun AdjustmentsPanel(vm: EditorViewModel, onOpen: (Adj) -> Unit) {
    var menuOpen by remember { mutableStateOf(false) }
    PanelCard {
        CardHeader("Adjustments") {
            Box {
                Box(Modifier.size(36.dp).clickable { menuOpen = true }, contentAlignment = Alignment.Center) {
                    FIcon(Ic.Menu, size = 22.dp, tint = TextDim)
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(text = { Text("Reset adjustments") }, onClick = { menuOpen = false; vm.resetEdits() })
                }
            }
        }
        Column(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Adj.values().toList().chunked(5).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    row.forEach { a ->
                        Box(
                            Modifier.size(48.dp).alpha(if (a.implemented) 1f else 0.4f)
                                .clip(RoundedCornerShape(8.dp)).clickable { onOpen(a) },
                            contentAlignment = Alignment.Center
                        ) { FIcon(a.icon, size = 30.dp) }
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun FieldBox(label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 14.sp, color = TextDim, modifier = Modifier.width(24.dp))
        Box(Modifier.width(96.dp).border(1.dp, Line, RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 7.dp)) {
            Text(value, fontSize = 14.sp)
        }
    }
}

@Composable
fun PropertiesPanel(vm: EditorViewModel) {
    val b = vm.bitmap
    val l = vm.activeLayer
    var open by remember { mutableStateOf(true) }
    val soon: (String) -> Unit = { vm.toast("$it قريباً") }
    val px = (l?.mx ?: 0) + vm.pendingMove.x.roundToInt()
    val py = (l?.my ?: 0) + vm.pendingMove.y.roundToInt()
    PanelCard {
        CardHeader("Properties") {
            Box(Modifier.alpha(0.55f).size(36.dp).clickable { soon("Properties menu") }, contentAlignment = Alignment.Center) {
                FIcon(Ic.Menu, size = 22.dp, tint = TextDim)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).background(Color(0xFF2A3350), RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                FIcon(Ic.PixelLayer, size = 28.dp)
            }
            Spacer(Modifier.width(12.dp))
            Text(if (l != null) "Pixel Layer" else "Background", fontSize = 15.sp)
        }
        Row(
            Modifier.fillMaxWidth().clickable { open = !open }.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FIcon(Ic.Chevron, size = 16.dp, tint = TextDim)
            Spacer(Modifier.width(8.dp))
            Text("Transform", fontSize = 15.sp)
        }
        if (open) {
            Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FieldBox("W:", "${b?.width ?: 0} px")
                    FieldBox("X:", "$px px")
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FieldBox("H:", "${b?.height ?: 0} px")
                    FieldBox("Y:", "$py px")
                }
                Row(
                    Modifier.alpha(0.5f).clickable { soon("Rotate") },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FIcon(Ic.Angle, size = 22.dp)
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.border(1.dp, Line, RoundedCornerShape(6.dp)).padding(horizontal = 10.dp, vertical = 7.dp)) {
                        Text("0.00\u00B0", fontSize = 14.sp)
                    }
                }
                Row(Modifier.fillMaxWidth().alpha(0.5f), horizontalArrangement = Arrangement.SpaceEvenly) {
                    listOf(Ic.FlipH, Ic.FlipV, Ic.AlignL, Ic.AlignCH, Ic.AlignR).forEach {
                        Box(Modifier.clickable { soon("Transform") }.padding(6.dp)) { FIcon(it, size = 22.dp) }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
fun SidePanel(vm: EditorViewModel, onAdj: (Adj) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        LayersPanel(vm)
        AdjustmentsPanel(vm, onAdj)
        PropertiesPanel(vm)
    }
}

// ---------------- Colors ----------------

private val palette = listOf(
    0xFF000000, 0xFFFFFFFF, 0xFF8E8E93, 0xFFFF3B30, 0xFFFF9500, 0xFFFFCC00, 0xFF34C759, 0xFF00C7BE, 0xFF1E7BFF, 0xFF5856D6,
    0xFFAF52DE, 0xFFFF2D55, 0xFFA2845E, 0xFF7A1F1F, 0xFFFFD9B3, 0xFFB6F0B6, 0xFFB3E5FF, 0xFFD7C4FF, 0xFF1C1C1E, 0xFF3A3A3C
)

@Composable
fun ColorPalette(selected: Int, onPick: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        palette.chunked(10).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { c ->
                    val argb = Color(c).toArgb()
                    Box(
                        Modifier.weight(1f).aspectRatio(1f).padding(2.dp)
                            .background(Color(c), RoundedCornerShape(6.dp))
                            .border(if (selected == argb) 3.dp else 1.dp,
                                if (selected == argb) Accent else TextDim, RoundedCornerShape(6.dp))
                            .clickable { onPick(argb) }
                    )
                }
            }
        }
    }
}
