package com.faris.studio.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.faris.studio.EditorViewModel
import com.faris.studio.Tool
import com.faris.studio.core.BlendKind
import com.faris.studio.core.Brushes
import com.faris.studio.core.FilterPreset
import com.faris.studio.core.Filters
import com.faris.studio.core.Gradients
import com.faris.studio.core.TileDef
import com.faris.studio.core.Tiles
import kotlin.math.roundToInt

enum class BTab(val label: String, val implemented: Boolean) {
    Filters("Filters", true),
    Effects("Effects", true),
    Styles("Styles", false),
    Textures("Textures", true),
    Brushes("Brushes", true),
    Gradients("Gradients", true),
    Patterns("Patterns", true)
}

enum class Adj(val label: String, val glyph: String, val implemented: Boolean) {
    BrightContrast("Brightness / Contrast", "☀", true),
    Curves("Curves", "⌗", false),
    Levels("Levels", "▥", true),
    Exposure("Exposure", "◪", true),
    Vibrance("Vibrance", "▲", false),
    HueSat("Hue / Saturation", "◍", true),
    ColorBalance("Color Balance", "⚖", true),
    BlackWhite("Black & White", "◑", true),
    PhotoFilter("Photo Filter", "📷", true),
    ChannelMixer("Channel Mixer", "▦", false),
    Invert("Invert", "◩", true),
    Posterize("Posterize", "▤", false),
    Threshold("Threshold", "◢", false),
    GradientMap("Gradient Map", "▭", false),
    SelectiveColor("Selective Color", "◈", false)
}

@Composable
fun LabeledSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String,
    onChange: (Float) -> Unit, onDone: () -> Unit = {}, modifier: Modifier = Modifier
) {
    Column(modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 12.sp, color = TextDim)
            Text(valueText, fontSize = 12.sp)
        }
        Slider(
            value = value, onValueChange = onChange, onValueChangeFinished = onDone, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
        )
    }
}

@Composable
fun MiniSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String,
    onChange: (Float) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 11.sp, color = TextDim)
        Slider(
            value = value, onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent),
            modifier = Modifier.width(110.dp)
        )
        Text(valueText, fontSize = 11.sp)
    }
}

@Composable
fun AdjustDialogBody(vm: EditorViewModel, adj: Adj) {
    val e = vm.edit
    Column {
        when (adj) {
            Adj.BrightContrast -> {
                LabeledSlider("Brightness", e.brightness.toFloat(), -100f..100f, "${e.brightness}",
                    { vm.previewEdit(vm.edit.copy(brightness = it.roundToInt())) }, { vm.commitPreview() })
                LabeledSlider("Contrast", e.contrast.toFloat(), -100f..100f, "${e.contrast}",
                    { vm.previewEdit(vm.edit.copy(contrast = it.roundToInt())) }, { vm.commitPreview() })
            }
            Adj.Levels -> {
                LabeledSlider("Input black", e.levelsLo.toFloat(), 0f..250f, "${e.levelsLo}",
                    { vm.previewEdit(vm.edit.copy(levelsLo = it.roundToInt().coerceAtMost(vm.edit.levelsHi - 5))) },
                    { vm.commitPreview() })
                LabeledSlider("Input white", e.levelsHi.toFloat(), 5f..255f, "${e.levelsHi}",
                    { vm.previewEdit(vm.edit.copy(levelsHi = it.roundToInt().coerceAtLeast(vm.edit.levelsLo + 5))) },
                    { vm.commitPreview() })
            }
            Adj.Exposure -> {
                LabeledSlider("Exposure", e.exposure.toFloat(), -100f..100f, "${e.exposure}",
                    { vm.previewEdit(vm.edit.copy(exposure = it.roundToInt())) }, { vm.commitPreview() })
            }
            Adj.HueSat -> {
                LabeledSlider("Hue", e.hue.toFloat(), -180f..180f, "${e.hue}",
                    { vm.previewEdit(vm.edit.copy(hue = it.roundToInt())) }, { vm.commitPreview() })
                LabeledSlider("Saturation", e.saturation.toFloat(), -100f..100f, "${e.saturation}",
                    { vm.previewEdit(vm.edit.copy(saturation = it.roundToInt())) }, { vm.commitPreview() })
            }
            Adj.ColorBalance -> {
                LabeledSlider("Red", e.balR.toFloat(), -100f..100f, "${e.balR}",
                    { vm.previewEdit(vm.edit.copy(balR = it.roundToInt())) }, { vm.commitPreview() })
                LabeledSlider("Green", e.balG.toFloat(), -100f..100f, "${e.balG}",
                    { vm.previewEdit(vm.edit.copy(balG = it.roundToInt())) }, { vm.commitPreview() })
                LabeledSlider("Blue", e.balB.toFloat(), -100f..100f, "${e.balB}",
                    { vm.previewEdit(vm.edit.copy(balB = it.roundToInt())) }, { vm.commitPreview() })
            }
            Adj.PhotoFilter -> {
                LabeledSlider("Cool ↔ Warm", e.tint.toFloat(), -100f..100f, "${e.tint}",
                    { vm.previewEdit(vm.edit.copy(tint = it.roundToInt())) }, { vm.commitPreview() })
            }
            else -> {}
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(BarBg).padding(10.dp)) {
        Text(title, fontSize = 15.sp, color = Accent, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
fun AdjustmentsPanel(onOpen: (Adj) -> Unit) {
    Section("Adjustments") {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Adj.values().toList().chunked(5).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    row.forEach { a ->
                        Box(
                            Modifier.size(46.dp)
                                .alpha(if (a.implemented) 1f else 0.35f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(PanelBg)
                                .clickable { onOpen(a) },
                            contentAlignment = Alignment.Center
                        ) { Text(a.glyph, fontSize = 22.sp) }
                    }
                }
            }
        }
    }
}

@Composable
private fun LayerRow(
    name: String, thumbBitmap: android.graphics.Bitmap?, visible: Boolean, selected: Boolean,
    locked: Boolean, onToggle: () -> Unit, onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (selected) Selected else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("👁", fontSize = 18.sp,
            modifier = Modifier.alpha(if (visible) 1f else 0.3f).clickable(onClick = onToggle).padding(4.dp))
        Spacer(Modifier.width(8.dp))
        Box(Modifier.size(width = 46.dp, height = 34.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF2A3350))) {
            if (thumbBitmap != null) {
                Image(
                    bitmap = thumbBitmap.asImageBitmap(), contentDescription = null,
                    contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                )
            }
        }
        Spacer(Modifier.width(10.dp))
        Text(name, fontSize = 14.sp, modifier = Modifier.weight(1f), maxLines = 1)
        if (locked) Text("🔒", fontSize = 14.sp)
    }
}

@Composable
fun LayersPanel(vm: EditorViewModel) {
    @Suppress("UNUSED_VARIABLE")
    val cv = vm.commitVersion // refresh thumbnails after each committed change
    val active = vm.activeLayer
    var blendOpen by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(BarBg)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Layers", fontSize = 15.sp, color = Accent, fontWeight = FontWeight.SemiBold)
            Text("Channels", fontSize = 13.sp, color = TextDim.copy(alpha = 0.5f),
                modifier = Modifier.clickable { vm.toast("Channels قريباً") })
            Text("Paths", fontSize = 13.sp, color = TextDim.copy(alpha = 0.5f),
                modifier = Modifier.clickable { vm.toast("Paths قريباً") })
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box {
                OutlinedButton(
                    onClick = { blendOpen = true }, enabled = active != null,
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) { Text(active?.blend?.label ?: "Normal", fontSize = 12.sp) }
                DropdownMenu(expanded = blendOpen, onDismissRequest = { blendOpen = false }) {
                    BlendKind.values().forEach { k ->
                        DropdownMenuItem(
                            text = { Text(k.label, fontSize = 14.sp) },
                            onClick = { blendOpen = false; active?.blend = k }
                        )
                    }
                }
            }
            Spacer(Modifier.width(8.dp))
            Text("Opacity", fontSize = 11.sp, color = TextDim)
            Slider(
                value = active?.opacity ?: 1f,
                onValueChange = { active?.opacity = it },
                enabled = active != null,
                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent),
                modifier = Modifier.weight(1f)
            )
            Text("${((active?.opacity ?: 1f) * 100).roundToInt()}%", fontSize = 11.sp)
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Lock:", fontSize = 12.sp, color = TextDim)
            Spacer(Modifier.width(8.dp))
            Text(
                if (active?.locked == true) "🔒" else "🔓", fontSize = 18.sp,
                modifier = Modifier.clickable { active?.let { it.locked = !it.locked } }.padding(4.dp)
            )
        }
        vm.layers.asReversed().forEach { l ->
            LayerRow(l.name, l.bitmap, l.visible, vm.activeLayerId == l.id, l.locked,
                onToggle = { l.visible = !l.visible }, onClick = { vm.selectLayer(l.id) })
        }
        LayerRow("Background", vm.thumb, vm.bgVisible, vm.activeLayerId == -1, true,
            onToggle = { vm.toggleBackground() }, onClick = { vm.selectLayer(-1) })
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("⧉", fontSize = 20.sp, modifier = Modifier.clickable { vm.duplicateLayer() }.padding(horizontal = 12.dp, vertical = 4.dp))
            Text("＋", fontSize = 22.sp, color = Accent, modifier = Modifier.clickable { vm.addLayer() }.padding(horizontal = 12.dp, vertical = 4.dp))
            Text("🗑", fontSize = 18.sp, modifier = Modifier.clickable { vm.deleteActiveLayer() }.padding(horizontal = 12.dp, vertical = 4.dp))
        }
    }
}

@Composable
fun PropertiesPanel(vm: EditorViewModel) {
    val b = vm.bitmap
    val l = vm.activeLayer
    Section("Properties") {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(if (l != null) "Pixel Layer — ${l.name}" else "Background (Image)", fontSize = 13.sp)
            Text("Transform", fontSize = 12.sp, color = TextDim)
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("W: ${b?.width ?: 0} px", fontSize = 13.sp)
                Text("H: ${b?.height ?: 0} px", fontSize = 13.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("X: ${l?.mx ?: 0} px", fontSize = 13.sp)
                Text("Y: ${l?.my ?: 0} px", fontSize = 13.sp)
            }
            Text("لتحريك الطبقة استخدم أداة Move", fontSize = 11.sp, color = TextDim)
        }
    }
}

@Composable
fun SidePanel(vm: EditorViewModel, onAdj: (Adj) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        LayersPanel(vm)
        AdjustmentsPanel(onAdj)
        PropertiesPanel(vm)
    }
}

// ---------------- Bottom strip ----------------

@Composable
fun FilterTile(vm: EditorViewModel, p: FilterPreset, modifier: Modifier = Modifier) {
    val sel = vm.edit.filterId == p.id
    Column(
        modifier
            .clip(RoundedCornerShape(8.dp))
            .border(2.dp, if (sel) Accent else Color.Transparent, RoundedCornerShape(8.dp))
            .clickable { vm.setFilter(p.id) }
            .padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val t = vm.tileBitmap(p)
        if (t != null) {
            Image(
                bitmap = t.asImageBitmap(), contentDescription = p.label, contentScale = ContentScale.Crop,
                colorFilter = ColorFilter.colorMatrix(ColorMatrix(Filters.presetArray(p))),
                modifier = Modifier.fillMaxWidth().aspectRatio(1.25f).clip(RoundedCornerShape(6.dp))
            )
        } else {
            Box(Modifier.fillMaxWidth().aspectRatio(1.25f).background(PanelBg, RoundedCornerShape(6.dp)))
        }
        Text(p.label, fontSize = 11.sp, maxLines = 1, color = if (sel) Accent else TextDim)
    }
}

@Composable
private fun FilterStrip(vm: EditorViewModel) {
    Column {
        if (vm.processing) Text("Processing…", fontSize = 11.sp, color = Accent)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(Filters.strip) { FilterTile(vm, it, Modifier.width(84.dp)) }
        }
    }
}

@Composable
private fun TileStrip(vm: EditorViewModel, tiles: List<TileDef>) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            StripTile("Solid", vm.activeTile == null) { vm.activeTile = null; vm.selectTool(Tool.Fill) }
        }
        items(tiles) { t ->
            StripTile(t.label, vm.activeTile == t.id, content = {
                Image(
                    bitmap = Tiles.get(t.id).asImageBitmap(), contentDescription = t.label,
                    contentScale = ContentScale.FillBounds,
                    colorFilter = ColorFilter.tint(Color.White),
                    modifier = Modifier.fillMaxSize()
                )
            }) { vm.activeTile = t.id; vm.selectTool(Tool.Fill) }
        }
    }
}

@Composable
private fun BrushStrip(vm: EditorViewModel) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(Brushes.list) { b ->
            val sel = vm.tool == Tool.Brush && vm.brushFrac == b.sizeFrac && vm.brushSoft == b.soft
            StripTile(b.name, sel, content = {
                Text("●", fontSize = (10 + b.sizeFrac * 70).sp, color = Color.White.copy(alpha = 0.35f + 0.65f * b.alpha),
                    modifier = Modifier.align(Alignment.Center))
            }) { vm.selectBrushPreset(b) }
        }
    }
}

@Composable
private fun GradientStrip(vm: EditorViewModel) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed2(Gradients.list) { i, g ->
            val colors = g.colors?.map { Color(it) } ?: listOf(Color(vm.brushColor), Color(vm.bgColor))
            StripTile(g.name, vm.gradIndex == i && vm.tool == Tool.Gradient, content = {
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(colors)))
            }) { vm.gradIndex = i; vm.selectTool(Tool.Gradient) }
        }
    }
}

private fun <T> androidx.compose.foundation.lazy.LazyListScope.itemsIndexed2(
    list: List<T>, content: @Composable (Int, T) -> Unit
) {
    items(list.size) { i -> content(i, list[i]) }
}

@Composable
private fun StripTile(
    label: String, selected: Boolean,
    content: @Composable BoxScope.() -> Unit = {},
    onClick: () -> Unit
) {
    Column(
        Modifier.width(84.dp).clip(RoundedCornerShape(8.dp))
            .border(2.dp, if (selected) Accent else Color.Transparent, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick).padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1.25f).clip(RoundedCornerShape(6.dp)).background(Color(0xFF2A3350)),
            content = content
        )
        Text(label, fontSize = 11.sp, maxLines = 1, color = if (selected) Accent else TextDim)
    }
}

@Composable
private fun EffectsPanel(vm: EditorViewModel) {
    val e = vm.edit
    Column {
        LabeledSlider("Vignette", e.vignette.toFloat(), 0f..100f, "${e.vignette}",
            { vm.previewEdit(vm.edit.copy(vignette = it.roundToInt())) }, { vm.commitPreview() })
        Text("مؤثرات أخرى (Glow, Grain, Lens Flare) تأتي بمراحل لاحقة.", fontSize = 11.sp, color = TextDim)
    }
}

@Composable
fun BottomStrip(vm: EditorViewModel, tab: BTab) {
    when (tab) {
        BTab.Filters -> FilterStrip(vm)
        BTab.Effects -> EffectsPanel(vm)
        BTab.Styles -> Text("Styles قريباً", color = TextDim, fontSize = 12.sp)
        BTab.Textures -> TileStrip(vm, Tiles.textures)
        BTab.Patterns -> TileStrip(vm, Tiles.patterns)
        BTab.Brushes -> BrushStrip(vm)
        BTab.Gradients -> GradientStrip(vm)
    }
}

// ---------------- Colors ----------------

private val palette = listOf(
    0xFF000000, 0xFFFFFFFF, 0xFF8E8E93, 0xFFFF3B30, 0xFFFF9500, 0xFFFFCC00, 0xFF34C759, 0xFF00C7BE, 0xFF1E7BFF, 0xFF5856D6,
    0xFFAF52DE, 0xFFFF2D55, 0xFFA2845E, 0xFF7A1F1F, 0xFFFFD9B3, 0xFFB6F0B6, 0xFFB3E5FF, 0xFFD7C4FF, 0xFF1C1C1E, 0xFF3A3A3C
)

@Composable
fun ColorPalette(selected: Int, onPick: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        palette.chunked(10).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { c ->
                    val argb = Color(c).toArgb()
                    Box(
                        Modifier.weight(1f).aspectRatio(1f).padding(2.dp)
                            .background(Color(c), RoundedCornerShape(6.dp))
                            .border(if (selected == argb) 3.dp else 1.dp,
                                if (selected == argb) Accent else TextDim, RoundedCornerShape(6.dp))
                            .clickable { onPick(argb) }
                    )
                }
            }
        }
    }
}
