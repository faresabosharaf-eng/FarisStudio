package com.faris.studio.core

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

enum class ShapeKind { Rect, Ellipse, Line }

enum class BlendKind(val label: String, val pd: PorterDuff.Mode?) {
    Normal("Normal", null),
    Multiply("Multiply", PorterDuff.Mode.MULTIPLY),
    Screen("Screen", PorterDuff.Mode.SCREEN),
    Overlay("Overlay", PorterDuff.Mode.OVERLAY),
    Darken("Darken", PorterDuff.Mode.DARKEN),
    Lighten("Lighten", PorterDuff.Mode.LIGHTEN)
}

sealed interface PaintOp {
    val clip: Path?
}

class StrokeOp(
    val pts: List<PointF>, val color: Int, val size: Float, val alpha: Int,
    val eraser: Boolean, val soft: Float, override val clip: Path?
) : PaintOp

class TextOp(
    val text: String, val x: Float, val y: Float, val color: Int, val size: Float,
    val alpha: Int, override val clip: Path?
) : PaintOp

class ShapeOp(
    val kind: ShapeKind, val x1: Float, val y1: Float, val x2: Float, val y2: Float,
    val color: Int, val stroke: Float, val alpha: Int, val filled: Boolean, override val clip: Path?
) : PaintOp

class GradientOp(
    val x1: Float, val y1: Float, val x2: Float, val y2: Float, val colors: IntArray,
    val radial: Boolean, val alpha: Int, override val clip: Path?
) : PaintOp

class FillOp(
    val color: Int, val tile: String?, val tileScale: Float, val alpha: Int, override val clip: Path?
) : PaintOp

class ClearOp(override val clip: Path?) : PaintOp

class MoveOp(val dx: Int, val dy: Int) : PaintOp {
    override val clip: Path? get() = null
}

/** A transparent drawing layer. Its pixels are the replay of [ops], so undo is exact. */
class PaintLayer(val id: Int, val name: String, w: Int, h: Int) {
    val bitmap: Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val ops = ArrayList<PaintOp>()
    var visible by mutableStateOf(true)
    var opacity by mutableStateOf(1f)
    var blend by mutableStateOf(BlendKind.Normal)
    var locked by mutableStateOf(false)
    var lockPixels by mutableStateOf(false)
    var lockPos by mutableStateOf(false)
    var mx by mutableStateOf(0)
    var my by mutableStateOf(0)
}

object PaintRenderer {
    fun strokePaint(color: Int, size: Float, alpha: Int, eraser: Boolean, soft: Float): Paint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            strokeWidth = size
            if (eraser) {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
            } else {
                this.color = color
                this.alpha = alpha
            }
            val radius = size * soft * 0.5f
            if (soft > 0.05f && radius > 0.5f) {
                maskFilter = BlurMaskFilter(radius, BlurMaskFilter.Blur.NORMAL)
            }
        }

    /** Applies one operation to a layer (MoveOp shifts pixels, others draw). */
    fun apply(layer: PaintLayer, op: PaintOp) {
        if (op is MoveOp) shift(layer.bitmap, op.dx, op.dy) else drawOp(Canvas(layer.bitmap), op)
    }

    fun redraw(layer: PaintLayer) {
        layer.bitmap.eraseColor(0)
        for (op in layer.ops) apply(layer, op)
    }

    private fun shift(bmp: Bitmap, dx: Int, dy: Int) {
        val copy = bmp.copy(Bitmap.Config.ARGB_8888, false)
        bmp.eraseColor(0)
        Canvas(bmp).drawBitmap(copy, dx.toFloat(), dy.toFloat(), null)
        copy.recycle()
    }

    fun drawOp(c: Canvas, op: PaintOp) {
        val clip = op.clip
        if (clip != null) {
            c.save()
            c.clipPath(clip)
        }
        when (op) {
            is StrokeOp -> drawStroke(c, op)
            is TextOp -> {
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                p.color = op.color
                p.alpha = op.alpha
                p.textSize = op.size
                c.drawText(op.text, op.x, op.y, p)
            }
            is ShapeOp -> drawShape(c, op)
            is GradientOp -> {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                val dist = max(1f, hypot(op.x2 - op.x1, op.y2 - op.y1))
                paint.shader = if (op.radial) {
                    RadialGradient(op.x1, op.y1, dist, op.colors, null, Shader.TileMode.CLAMP)
                } else {
                    LinearGradient(op.x1, op.y1, op.x2, op.y2, op.colors, null, Shader.TileMode.CLAMP)
                }
                paint.alpha = op.alpha
                c.drawPaint(paint)
            }
            is FillOp -> {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                if (op.tile != null) {
                    val sh = BitmapShader(Tiles.get(op.tile), Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
                    val m = Matrix()
                    m.setScale(op.tileScale, op.tileScale)
                    sh.setLocalMatrix(m)
                    paint.shader = sh
                    paint.colorFilter = PorterDuffColorFilter(op.color, PorterDuff.Mode.SRC_IN)
                } else {
                    paint.color = op.color
                }
                paint.alpha = op.alpha
                c.drawPaint(paint)
            }
            is ClearOp -> {
                val paint = Paint()
                paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
                c.drawPaint(paint)
            }
            is MoveOp -> {}
        }
        if (clip != null) c.restore()
    }

    private fun drawStroke(c: Canvas, op: StrokeOp) {
        val pts = op.pts
        if (pts.isEmpty()) return
        val paint = strokePaint(op.color, op.size, op.alpha, op.eraser, op.soft)
        if (pts.size == 1) {
            c.drawPoint(pts[0].x, pts[0].y, paint)
            return
        }
        val path = Path()
        path.moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) {
            val p0 = pts[i - 1]
            val p1 = pts[i]
            path.quadTo(p0.x, p0.y, (p0.x + p1.x) / 2f, (p0.y + p1.y) / 2f)
        }
        path.lineTo(pts.last().x, pts.last().y)
        c.drawPath(path, paint)
    }

    private fun drawShape(c: Canvas, op: ShapeOp) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = op.color
        paint.alpha = op.alpha
        paint.strokeWidth = op.stroke
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.style = if (op.filled && op.kind != ShapeKind.Line) Paint.Style.FILL else Paint.Style.STROKE
        val l = min(op.x1, op.x2)
        val t = min(op.y1, op.y2)
        val r = max(op.x1, op.x2)
        val b = max(op.y1, op.y2)
        when (op.kind) {
            ShapeKind.Rect -> c.drawRect(l, t, r, b, paint)
            ShapeKind.Ellipse -> c.drawOval(RectF(l, t, r, b), paint)
            ShapeKind.Line -> c.drawLine(op.x1, op.y1, op.x2, op.y2, paint)
        }
    }
}
