package com.faris.studio.core

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

/** Spatial filters (Blur, Sharpen, HDR) implemented with fast box blurs. */
object SpatialFx {
    fun apply(src: Bitmap, kind: SpatialKind): Bitmap {
        val w = src.width
        val h = src.height
        val md = max(w, h)
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        when (kind) {
            SpatialKind.Blur -> boxBlur(px, w, h, max(2, md / 120), 3)
            SpatialKind.Sharpen -> unsharp(px, w, h, max(1, md / 500), 1.2f)
            SpatialKind.HDR -> unsharp(px, w, h, max(2, md / 40), 0.9f)
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun clamp(v: Float): Int = v.toInt().coerceIn(0, 255)

    private fun unsharp(px: IntArray, w: Int, h: Int, r: Int, amount: Float) {
        val blur = px.copyOf()
        boxBlur(blur, w, h, r, 2)
        for (i in px.indices) {
            val o = px[i]
            val b = blur[i]
            val orr = (o shr 16) and 255
            val og = (o shr 8) and 255
            val ob = o and 255
            val rr = clamp(orr + amount * (orr - ((b shr 16) and 255)))
            val gg = clamp(og + amount * (og - ((b shr 8) and 255)))
            val bb = clamp(ob + amount * (ob - (b and 255)))
            px[i] = (o and 0xFF000000.toInt()) or (rr shl 16) or (gg shl 8) or bb
        }
    }

    private fun boxBlur(px: IntArray, w: Int, h: Int, r: Int, passes: Int) {
        val tmp = IntArray(px.size)
        repeat(passes) {
            blurH(px, tmp, w, h, r)
            blurV(tmp, px, w, h, r)
        }
    }

    private fun blurH(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            var sa = 0
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val p = src[row + i.coerceIn(0, w - 1)]
                sa += p ushr 24
                sr += (p shr 16) and 255
                sg += (p shr 8) and 255
                sb += p and 255
            }
            for (x in 0 until w) {
                dst[row + x] = ((sa / div) shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = src[row + min(x + r + 1, w - 1)]
                val rem = src[row + max(x - r, 0)]
                sa += (add ushr 24) - (rem ushr 24)
                sr += ((add shr 16) and 255) - ((rem shr 16) and 255)
                sg += ((add shr 8) and 255) - ((rem shr 8) and 255)
                sb += (add and 255) - (rem and 255)
            }
        }
    }

    private fun blurV(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (x in 0 until w) {
            var sa = 0
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val p = src[i.coerceIn(0, h - 1) * w + x]
                sa += p ushr 24
                sr += (p shr 16) and 255
                sg += (p shr 8) and 255
                sb += p and 255
            }
            for (y in 0 until h) {
                dst[y * w + x] = ((sa / div) shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = src[min(y + r + 1, h - 1) * w + x]
                val rem = src[max(y - r, 0) * w + x]
                sa += (add ushr 24) - (rem ushr 24)
                sr += ((add shr 16) and 255) - ((rem shr 16) and 255)
                sg += ((add shr 8) and 255) - ((rem shr 8) and 255)
                sb += (add and 255) - (rem and 255)
            }
        }
    }
}
